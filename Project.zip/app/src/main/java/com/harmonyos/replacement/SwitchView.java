package com.harmonyos.replacement;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/** Pill switch that animates like the HarmonyOS one. */
public class SwitchView extends View {
    boolean on;
    float t;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final int offColor;
    ValueAnimator va;

    public SwitchView(Context c, int offColor) {
        super(c);
        this.offColor = offColor;
    }

    public void setOn(boolean o, boolean animate) {
        on = o;
        if (va != null) va.cancel();
        float to = o ? 1f : 0f;
        if (!animate) { t = to; invalidate(); return; }
        va = ValueAnimator.ofFloat(t, to);
        va.setDuration(250);
        va.addUpdateListener(a -> { t = (float) a.getAnimatedValue(); invalidate(); });
        va.start();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        p.setColor((int) new ArgbEvaluator().evaluate(t, offColor, 0xFF1F6FE0));
        c.drawRoundRect(0, 0, w, h, h / 2, h / 2, p);
        p.setColor(Color.WHITE);
        c.drawCircle(h / 2 + (w - h) * t, h / 2, h * 0.385f, p);
    }
}
