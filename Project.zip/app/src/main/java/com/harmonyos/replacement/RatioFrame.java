package com.harmonyos.replacement;

import android.content.Context;
import android.widget.FrameLayout;

/** FrameLayout that is always 3:2 (width : height), like the banner and the update video. */
public class RatioFrame extends FrameLayout {
    public RatioFrame(Context c) { super(c); }

    @Override
    protected void onMeasure(int w, int h) {
        int ww = MeasureSpec.getSize(w);
        super.onMeasure(MeasureSpec.makeMeasureSpec(ww, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(ww * 2 / 3, MeasureSpec.EXACTLY));
    }
}
