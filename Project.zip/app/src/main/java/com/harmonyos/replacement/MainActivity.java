package com.harmonyos.replacement;

import android.app.Activity;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * HarmonyOS-style Settings. The category list and every page live in res/raw/data.txt,
 * so adding or editing rows never needs Java changes.
 */
public class MainActivity extends Activity {
    static class Page {
        String title;
        boolean sub;
        final List<String[]> lines = new ArrayList<>();
    }

    final Map<String, Page> pages = new HashMap<>();
    final List<List<String[]>> left = new ArrayList<>();
    final Map<String, View> leftViews = new HashMap<>();
    final ArrayList<String> stack = new ArrayList<>();
    LinearLayout root, leftList;
    FrameLayout right;
    View current;
    SharedPreferences prefs;
    boolean dark;
    String cat = "wifi";
    int bg, card, tx, mu, bl, sel, ln, off;

    // software-update video state
    MediaPlayer mp;
    TextureView tex;
    TextView status, btn;
    boolean ready, want;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("settings", 0);
        dark = prefs.getBoolean("dark", false);
        theme();
        load();
        root = new LinearLayout(this);
        root.setFitsSystemWindows(true);
        ScrollView ls = new ScrollView(this);
        ls.setVerticalScrollBarEnabled(false);
        leftList = new LinearLayout(this);
        leftList.setOrientation(LinearLayout.VERTICAL);
        leftList.setPadding(dp(14), 0, dp(10), dp(14));
        ls.addView(leftList);
        right = new FrameLayout(this);
        root.addView(ls, new LinearLayout.LayoutParams(0, -1, 4f));
        root.addView(right, new LinearLayout.LayoutParams(0, -1, 6f));
        setContentView(root);
        skin();
        buildLeft();
        stack.add(cat);
        showTop();
    }

    // ---------- theme ----------
    void theme() {
        bg = dark ? 0xFF000000 : 0xFFF3F0FA;
        card = dark ? 0xFF1C1C1E : 0xFFFFFFFF;
        tx = dark ? 0xFFECECEC : 0xFF111111;
        mu = dark ? 0xFF8A8A8E : 0xFF7A7A80;
        bl = dark ? 0xFF2F8FE8 : 0xFF1F6FE0;
        sel = dark ? 0x66264A8C : 0x24286EE6;
        ln = dark ? 0xFF2C2C2E : 0xFFEBEBEF;
        off = dark ? 0xFF555555 : 0xFFC4C4C8;
    }

    void skin() {
        root.setBackgroundColor(bg);
        getWindow().setStatusBarColor(bg);
        getWindow().setNavigationBarColor(bg);
        int f = dark ? 0 : (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        getWindow().getDecorView().setSystemUiVisibility(f);
    }

    void setDark(boolean n) {
        dark = n;
        prefs.edit().putBoolean("dark", n).apply();
        theme();
        skin();
        buildLeft();
        showTop();
    }

    // ---------- data ----------
    static String g(String[] f, int i) { return i < f.length ? f[i] : ""; }

    void load() {
        try {
            BufferedReader br = new BufferedReader(new InputStreamReader(getResources().openRawResource(R.raw.data), "UTF-8"));
            String line;
            Page cur = null;
            boolean inLeft = false;
            List<String[]> grp = null;
            while ((line = br.readLine()) != null) {
                if (line.trim().isEmpty() || line.startsWith("//")) continue;
                if (line.equals("#left")) { inLeft = true; grp = new ArrayList<>(); left.add(grp); continue; }
                if (line.startsWith("== ")) {
                    inLeft = false;
                    String[] h = line.substring(3).split("\\|", -1);
                    cur = new Page();
                    cur.title = h[1];
                    cur.sub = h.length > 2 && h[2].equals("sub");
                    pages.put(h[0], cur);
                    continue;
                }
                if (inLeft) {
                    if (line.equals("--")) { grp = new ArrayList<>(); left.add(grp); }
                    else grp.add(line.split("\\|", -1));
                } else if (cur != null) cur.lines.add(line.split("\\|", -1));
            }
            br.close();
        } catch (Exception e) { throw new RuntimeException(e); }
    }

    // ---------- small view helpers ----------
    int dp(float v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    TextView txt(String s, float size, int c) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size);
        t.setTextColor(c);
        return t;
    }

    GradientDrawable rr(int c, float r) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(c);
        d.setCornerRadius(dp(r));
        return d;
    }

    View rounded(View v, final int r) {
        v.setOutlineProvider(new ViewOutlineProvider() {
            @Override public void getOutline(View vw, Outline o) { o.setRoundRect(0, 0, vw.getWidth(), vw.getHeight(), r); }
        });
        v.setClipToOutline(true);
        return v;
    }

    ImageView icon(String n) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(getResources().getIdentifier("ic_" + n, "drawable", getPackageName()));
        return iv;
    }

    View chev() {
        ImageView c = icon("chev");
        c.setColorFilter(mu);
        c.setAlpha(.7f);
        c.setLayoutParams(new LinearLayout.LayoutParams(dp(16), dp(16)));
        return c;
    }

    LinearLayout cardBox() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(rr(card, 18));
        c.setPadding(dp(3), dp(3), dp(3), dp(3));
        return c;
    }

    LinearLayout.LayoutParams cardLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.bottomMargin = dp(14);
        return p;
    }

    LinearLayout.LayoutParams mediaLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = dp(4);
        p.bottomMargin = dp(14);
        return p;
    }

    View divider(int startDp) {
        View v = new View(this);
        v.setBackgroundColor(ln);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, 1);
        p.leftMargin = dp(startDp);
        p.rightMargin = dp(startDp > 20 ? 12 : 14);
        v.setLayoutParams(p);
        return v;
    }

    View searchPill(String label) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(14), 0, dp(14), 0);
        r.setBackground(rr(card, 22));
        ImageView s = icon("search");
        s.setColorFilter(mu);
        r.addView(s, new LinearLayout.LayoutParams(dp(20), dp(20)));
        TextView t = txt(label, 15, mu);
        t.setPadding(dp(8), 0, 0, 0);
        r.addView(t);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(40));
        p.bottomMargin = dp(14);
        r.setLayoutParams(p);
        return r;
    }

    // ---------- left pane ----------
    void buildLeft() {
        leftList.removeAllViews();
        leftViews.clear();
        TextView h = txt("Settings", 22, tx);
        h.setPadding(dp(6), dp(10), dp(6), dp(14));
        leftList.addView(h);
        leftList.addView(searchPill("Search"));

        LinearLayout pc = cardBox();
        LinearLayout pr = new LinearLayout(this);
        pr.setGravity(Gravity.CENTER_VERTICAL);
        pr.setMinimumHeight(dp(70));
        pr.setPadding(dp(12), 0, dp(12), 0);
        View av = new View(this);
        GradientDrawable ag = new GradientDrawable();
        ag.setShape(GradientDrawable.OVAL);
        ag.setColor(0xFF6B6B70);
        av.setBackground(ag);
        pr.addView(av, new LinearLayout.LayoutParams(dp(44), dp(44)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(14), dp(8), dp(8), dp(8));
        col.addView(txt("+63 917*****82", 16, tx));
        col.addView(txt("HUAWEI ID, Cloud, and more", 13, mu));
        pr.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        pr.addView(chev());
        pc.addView(pr);
        leftList.addView(pc, cardLp());

        for (List<String[]> grp : left) {
            LinearLayout c = cardBox();
            boolean first = true;
            for (String[] f : grp) {
                if (!first) c.addView(divider(58));
                first = false;
                View v = leftItem(f);
                leftViews.put(f[0], v);
                c.addView(v);
            }
            leftList.addView(c, cardLp());
        }
        markLeft();
    }

    View leftItem(final String[] f) {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(54));
        r.setPadding(dp(12), 0, dp(12), 0);
        FrameLayout ic = new FrameLayout(this);
        GradientDrawable gd = new GradientDrawable();
        gd.setShape(GradientDrawable.OVAL);
        if (f[0].equals("assist")) {
            gd.setOrientation(GradientDrawable.Orientation.TL_BR);
            gd.setColors(new int[]{0xFF7FD3FF, 0xFFC58BFF, 0xFFFF9CB0});
        } else gd.setColor(Color.parseColor(f[3]));
        ic.setBackground(gd);
        if (!g(f, 4).isEmpty()) {
            ic.addView(icon(f[4]), new FrameLayout.LayoutParams(dp(19), dp(19), Gravity.CENTER));
        } else if (f[0].equals("hms")) {
            TextView t = txt("HMS", 8, Color.WHITE);
            t.setTypeface(null, Typeface.BOLD);
            ic.addView(t, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        }
        r.addView(ic, new LinearLayout.LayoutParams(dp(32), dp(32)));
        TextView t = txt(f[1], 16, tx);
        t.setPadding(dp(14), dp(8), dp(8), dp(8));
        r.addView(t, new LinearLayout.LayoutParams(0, -2, 1f));
        if (!g(f, 2).isEmpty()) r.addView(txt(f[2], 14, mu));
        r.addView(chev());
        r.setOnClickListener(x -> pick(f[0]));
        return r;
    }

    void markLeft() {
        for (Map.Entry<String, View> e : leftViews.entrySet())
            e.getValue().setBackground(e.getKey().equals(cat) ? rr(sel, 15) : null);
    }

    // ---------- pages ----------
    View buildPage(String key) {
        Page p = pages.get(key);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(bg);
        page.setClickable(true);
        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(10), 0, dp(10), 0);
        if (p.sub) {
            ImageView bk = icon("back");
            bk.setColorFilter(tx);
            bk.setOnClickListener(x -> back());
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(26), dp(26));
            bp.rightMargin = dp(12);
            head.addView(bk, bp);
        }
        head.addView(txt(p.title, 18, tx));
        page.addView(head, new LinearLayout.LayoutParams(-1, dp(46)));
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(6), 0, dp(14), dp(30));
        TextureView before = tex;
        render(p, body);
        if (tex != before) page.setTag("vid");
        sv.addView(body);
        page.addView(sv, new LinearLayout.LayoutParams(-1, 0, 1f));
        return page;
    }

    void render(Page p, LinearLayout body) {
        LinearLayout c = null;
        for (String[] f : p.lines) {
            String k = f[0];
            if (k.equals("[")) { c = cardBox(); body.addView(c, cardLp()); }
            else if (k.equals("]")) c = null;
            else if (k.equals("h")) {
                TextView h = txt(g(f, 1), 13, mu);
                h.setLetterSpacing(.04f);
                h.setPadding(dp(10), dp(8), dp(10), dp(8));
                body.addView(h);
            } else if (k.equals("note")) {
                LinearLayout n = new LinearLayout(this);
                n.setOrientation(LinearLayout.VERTICAL);
                n.setPadding(dp(16), dp(14), dp(16), dp(14));
                n.setBackground(rr(card, 16));
                n.addView(txt(g(f, 1), 15, mu));
                for (int i = 2; i < f.length; i++) {
                    TextView l = txt(f[i], 15, bl);
                    l.setPadding(0, dp(10), 0, 0);
                    n.addView(l);
                }
                body.addView(n, cardLp());
            } else if (k.equals("srch")) body.addView(searchPill(g(f, 1)));
            else if (k.equals("ban")) body.addView(banner(false), mediaLp());
            else if (k.equals("vid")) {
                body.addView(banner(true), mediaLp());
                status = txt("Checking…", 22, tx);
                status.setGravity(Gravity.CENTER);
                status.setPadding(0, dp(14), 0, dp(22));
                body.addView(status);
            } else if (k.equals("chk")) {
                btn = txt(g(f, 1), 16, 0xFF2F8FE8);
                btn.setGravity(Gravity.CENTER);
                btn.setPadding(dp(34), dp(13), dp(34), dp(13));
                btn.setBackground(rr(0x471F6FE0, 24));
                btn.setOnClickListener(x -> { if (btn.isEnabled()) startCheck(); });
                LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-2, -2);
                bp.gravity = Gravity.CENTER_HORIZONTAL;
                bp.topMargin = dp(26);
                body.addView(btn, bp);
            } else if (k.equals("p")) {
                TextView t = txt(g(f, 1), 15, mu);
                t.setGravity(Gravity.CENTER);
                t.setPadding(0, dp(14), 0, dp(14));
                body.addView(t);
            } else if (c != null) {
                if (c.getChildCount() > 0) c.addView(divider(14));
                c.addView(row(f));
            }
        }
    }

    LinearLayout rowBox() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setMinimumHeight(dp(54));
        r.setPadding(dp(14), 0, dp(14), 0);
        return r;
    }

    LinearLayout titleCol(String title, int tc, String sub, int sc) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(0, dp(9), dp(8), dp(9));
        col.addView(txt(title, 16, tc));
        if (!sub.isEmpty()) {
            TextView s = txt(sub, 13, sc);
            s.setPadding(0, dp(2), 0, 0);
            col.addView(s);
        }
        return col;
    }

    View row(final String[] f) {
        String k = f[0];
        LinearLayout r = rowBox();
        if (k.equals("s")) {
            final boolean dm = g(f, 4).equals("dm");
            LinearLayout col = titleCol(f[1], tx, g(f, 3), g(f, 4).equals("b") ? bl : mu);
            r.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
            final SwitchView sw = new SwitchView(this, off);
            sw.setOn(dm ? dark : g(f, 2).equals("1"), false);
            r.addView(sw, new LinearLayout.LayoutParams(dp(46), dp(26)));
            r.setOnClickListener(x -> {
                final boolean n = !sw.on;
                sw.setOn(n, true);
                if (dm) x.postDelayed(() -> setDark(n), 230);
            });
        } else if (k.equals("a")) {
            r.addView(titleCol(f[1], bl, "", mu), new LinearLayout.LayoutParams(0, -2, 1f));
        } else if (k.equals("x")) {
            r.addView(titleCol(f[1], tx, "", mu), new LinearLayout.LayoutParams(0, -2, 1f));
            TextView v = txt(g(f, 2), 14, mu);
            v.setGravity(Gravity.END);
            r.addView(v, new LinearLayout.LayoutParams(0, -2, 1f));
        } else if (k.equals("sl")) {
            r.setOrientation(LinearLayout.VERTICAL);
            r.setGravity(Gravity.NO_GRAVITY);
            r.setPadding(dp(16), dp(12), dp(16), dp(8));
            r.addView(txt(f[1], 16, tx));
            SeekBar sb = new SeekBar(this);
            sb.setMax(100);
            sb.setProgress(Integer.parseInt(g(f, 2)));
            sb.setProgressTintList(ColorStateList.valueOf(0xFF1F6FE0));
            sb.setThumbTintList(ColorStateList.valueOf(0xFF1F6FE0));
            r.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        } else { // "n" navigation row
            String title = f[1];
            boolean blue = title.startsWith("*");
            if (blue) title = title.substring(1);
            if (!g(f, 5).isEmpty()) {
                TextView sq = txt(title.substring(0, 1), 15, Color.WHITE);
                sq.setTypeface(null, Typeface.BOLD);
                sq.setGravity(Gravity.CENTER);
                sq.setBackground(rr(Color.parseColor(f[5]), 9));
                LinearLayout.LayoutParams sqp = new LinearLayout.LayoutParams(dp(36), dp(36));
                sqp.rightMargin = dp(12);
                r.addView(sq, sqp);
            }
            r.addView(titleCol(title, blue ? bl : tx, g(f, 4), mu), new LinearLayout.LayoutParams(0, -2, 1f));
            if (!g(f, 2).isEmpty()) r.addView(txt(f[2], 14, mu));
            r.addView(chev());
            final String go = g(f, 3);
            if (!go.isEmpty()) r.setOnClickListener(x -> open(go));
        }
        return r;
    }

    View banner(boolean video) {
        RatioFrame f = new RatioFrame(this);
        if (video) {
            tex = new TextureView(this);
            ready = false;
            tex.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
                @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) { initPlayer(new Surface(st)); }
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { return true; }
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) { }
                @Override public void onSurfaceTextureUpdated(SurfaceTexture st) { }
            });
            f.addView(tex, new FrameLayout.LayoutParams(-1, -1));
        } else {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageResource(R.drawable.about_banner);
            f.addView(iv, new FrameLayout.LayoutParams(-1, -1));
        }
        rounded(f, dp(28));
        return f;
    }

    // ---------- software update video ----------
    void initPlayer(Surface s) {
        try {
            mp = new MediaPlayer();
            AssetFileDescriptor a = getResources().openRawResourceFd(R.raw.software_update);
            mp.setDataSource(a.getFileDescriptor(), a.getStartOffset(), a.getLength());
            a.close();
            mp.setSurface(s);
            mp.setVolume(0f, 0f);
            // the TextureView keeps the last frame, so the video "freezes" at the end
            mp.setOnCompletionListener(m -> finishCheck());
            mp.setOnPreparedListener(m -> { ready = true; if (want) mp.start(); });
            mp.prepareAsync();
        } catch (Exception e) { finishCheck(); }
    }

    void startCheck() {
        if (status == null || btn == null) return;
        status.setText("Checking…");
        btn.setEnabled(false);
        btn.setAlpha(.45f);
        want = true;
        if (ready && mp != null) mp.start(); // after completion, start() plays it again from 0
    }

    void finishCheck() {
        want = false;
        if (status != null) status.setText("Your device is up to date.");
        if (btn != null) { btn.setEnabled(true); btn.setAlpha(1f); }
    }

    void releaseVideo() {
        if (mp != null) { try { mp.release(); } catch (Exception ignored) { } mp = null; }
        ready = false;
        want = false;
        tex = null;
    }

    // ---------- navigation + animations ----------
    void pick(String key) {
        if (key.equals(cat) && stack.size() == 1) return;
        cat = key;
        stack.clear();
        stack.add(key);
        markLeft();
        transition(0, buildPage(key));
    }

    void open(String key) { stack.add(key); transition(1, buildPage(key)); }

    void back() {
        if (stack.size() < 2) return;
        stack.remove(stack.size() - 1);
        transition(2, buildPage(stack.get(stack.size() - 1)));
    }

    @Override
    public void onBackPressed() {
        if (stack.size() > 1) back(); else super.onBackPressed();
    }

    void showTop() {
        releaseVideo();
        right.removeAllViews();
        current = buildPage(stack.get(stack.size() - 1));
        right.addView(current, new FrameLayout.LayoutParams(-1, -1));
        markLeft();
        if ("vid".equals(current.getTag())) right.postDelayed(this::startCheck, 300);
    }

    void removeOld(View v) {
        if ("vid".equals(v.getTag())) releaseVideo();
        right.removeView(v);
    }

    /** mode 0 = category switch (soft slide + fade), 1 = push sub-page, 2 = pop. */
    void transition(int mode, View next) {
        for (int i = right.getChildCount() - 1; i >= 0; i--) {
            View c = right.getChildAt(i);
            if (c != current) { c.animate().cancel(); removeOld(c); }
        }
        final View old = current;
        current = next;
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-1, -1);
        if (mode == 2) right.addView(next, 0, lp); else right.addView(next, lp);
        int w = right.getWidth();
        long d = mode == 0 ? 320 : 380;
        if (old == null || w == 0) {
            if (old != null) removeOld(old);
            return;
        }
        PathInterpolator pi = new PathInterpolator(.22f, .8f, .24f, 1f);
        if (mode == 1) {
            next.setTranslationX(w);
            next.animate().translationX(0).setDuration(d).setInterpolator(pi);
            old.animate().translationX(-w * .28f).alpha(.4f).setDuration(d).setInterpolator(pi).withEndAction(() -> removeOld(old));
        } else if (mode == 2) {
            next.setTranslationX(-w * .28f);
            next.setAlpha(.4f);
            next.animate().translationX(0).alpha(1f).setDuration(d).setInterpolator(pi);
            old.animate().translationX(w).setDuration(d).setInterpolator(pi).withEndAction(() -> removeOld(old));
        } else {
            float s = dp(44);
            next.setTranslationX(s);
            next.setAlpha(0f);
            next.animate().translationX(0).alpha(1f).setDuration(d).setInterpolator(pi);
            old.animate().translationX(-s).alpha(0f).setDuration(d).setInterpolator(pi).withEndAction(() -> removeOld(old));
        }
        if ("vid".equals(next.getTag())) right.postDelayed(this::startCheck, d - 60);
    }

    @Override
    protected void onDestroy() {
        releaseVideo();
        super.onDestroy();
    }
}
