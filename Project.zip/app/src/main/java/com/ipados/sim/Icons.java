package com.ipados.sim;

import android.graphics.*;

/** Vector-drawn iOS-style app icons (100x100 design grid). */
final class Icons {
    static String calDay = "WED", calNum = "18";
    static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    static final Path PA = new Path(), CL = new Path();

    static void fill(int col) { P.setShader(null); P.setStyle(Paint.Style.FILL); P.setColor(col); }
    static void stroke(int col, float w) { P.setShader(null); P.setStyle(Paint.Style.STROKE); P.setStrokeWidth(w); P.setColor(col); P.setStrokeCap(Paint.Cap.ROUND); P.setStrokeJoin(Paint.Join.ROUND); }
    static void grad(Canvas c, int a, int b) { P.setStyle(Paint.Style.FILL); P.setShader(new LinearGradient(0, 0, 0, 100, a, b, Shader.TileMode.CLAMP)); c.drawRect(0, 0, 100, 100, P); P.setShader(null); }
    static void rr(Canvas c, float l, float t, float r, float b, float rad, int col) { fill(col); c.drawRoundRect(l, t, r, b, rad, rad, P); }
    static void ci(Canvas c, float x, float y, float r, int col) { fill(col); c.drawCircle(x, y, r, P); }
    static void ln(Canvas c, float x1, float y1, float x2, float y2, float w, int col) { stroke(col, w); c.drawLine(x1, y1, x2, y2, P); }
    static void poly(Canvas c, int col, float... q) {
        PA.reset(); PA.moveTo(q[0], q[1]);
        for (int i = 2; i < q.length; i += 2) PA.lineTo(q[i], q[i + 1]);
        PA.close(); fill(col); c.drawPath(PA, P);
    }
    static void text(Canvas c, String s, float x, float y, float size, int col, Typeface f) {
        fill(col); P.setTextSize(size); P.setTypeface(f); P.setTextAlign(Paint.Align.CENTER); c.drawText(s, x, y, P); P.setTypeface(null);
    }

    static void draw(Canvas c, String id, float x, float y, float s) {
        c.save(); c.translate(x, y); c.scale(s / 100f, s / 100f);
        CL.reset(); CL.addRoundRect(0, 0, 100, 100, 22.5f, 22.5f, Path.Direction.CW); c.clipPath(CL);
        switch (id) {
            case "ipados":
                grad(c, 0xFF45B0FF, 0xFF0B57E3);
                stroke(0xFFFFFFFF, 5); c.drawRoundRect(18, 28, 82, 72, 7, 7, P); ci(c, 74, 50, 2.6f, 0xFFFFFFFF); break;
            case "messages":
                grad(c, 0xFF67F07C, 0xFF0DB82A);
                fill(0xFFFFFFFF); c.drawOval(15, 22, 85, 70, P); poly(c, 0xFFFFFFFF, 26, 60, 17, 80, 46, 66); break;
            case "facetime":
                grad(c, 0xFF67F07C, 0xFF0DB82A);
                rr(c, 13, 30, 62, 70, 9, 0xFFFFFFFF); poly(c, 0xFFFFFFFF, 66, 47, 88, 32, 88, 68, 66, 53); break;
            case "mail":
                grad(c, 0xFF4FC3FA, 0xFF1C6FEF);
                rr(c, 15, 28, 85, 72, 7, 0xFFFFFFFF);
                PA.reset(); PA.moveTo(17, 32); PA.lineTo(50, 55); PA.lineTo(83, 32); stroke(0xFF2A7BF0, 4.5f); c.drawPath(PA, P); break;
            case "safari":
                grad(c, 0xFF40C9FF, 0xFF1163E8);
                ci(c, 50, 50, 37, 0x33FFFFFF); stroke(0xFFFFFFFF, 3); c.drawCircle(50, 50, 37, P);
                for (int i = 0; i < 12; i++) { c.save(); c.rotate(i * 30, 50, 50); ln(c, 50, 15, 50, i % 3 == 0 ? 22 : 19, 1.6f, 0xCCFFFFFF); c.restore(); }
                c.save(); c.rotate(45, 50, 50); poly(c, 0xFFFF3B30, 50, 20, 58, 50, 42, 50); poly(c, 0xFFFFFFFF, 50, 80, 58, 50, 42, 50); c.restore(); break;
            case "photos":
                fill(0xFFFFFFFF); c.drawRect(0, 0, 100, 100, P);
                int[] pc = {0xFFFFB700, 0xFFFF8A00, 0xFFFF3B5C, 0xFFD13AE0, 0xFF5B5BF5, 0xFF1EA7FF, 0xFF34C759, 0xFFB6E02A};
                for (int i = 0; i < 8; i++) { c.save(); c.rotate(i * 45, 50, 50); fill((pc[i] & 0xFFFFFF) | 0xC8000000); c.drawOval(40, 15, 60, 50, P); c.restore(); } break;
            case "maps":
                rr(c, 0, 0, 100, 100, 0, 0xFFF1EEE6); rr(c, 0, 62, 100, 100, 0, 0xFFBDE5A0);
                ln(c, -10, 80, 110, 10, 15, 0xFFFFD25A); ln(c, -10, 80, 110, 10, 9, 0xFFFFFFFF); ln(c, 30, 0, 52, 100, 6, 0xFFFFFFFF);
                poly(c, 0xFF2F7BF5, 56, 24, 70, 72, 56, 62, 42, 72); break;
            case "camera":
                grad(c, 0xFFBFC2C8, 0xFF6F7178);
                rr(c, 14, 32, 86, 76, 10, 0xFF1C1C1E); rr(c, 34, 25, 54, 38, 4, 0xFF1C1C1E);
                ci(c, 50, 54, 18, 0xFF48484A); ci(c, 50, 54, 12, 0xFF0A0A0C); ci(c, 46, 50, 3, 0x55FFFFFF); ci(c, 76, 41, 3, 0xFFFFD60A); break;
            case "settings":
                grad(c, 0xFFBABDC4, 0xFF6C6F77);
                for (int i = 0; i < 8; i++) { c.save(); c.rotate(i * 45, 50, 50); rr(c, 43, 12, 57, 32, 3, 0xFF3B3C41); c.restore(); }
                ci(c, 50, 50, 28, 0xFF3B3C41); ci(c, 50, 50, 20, 0xFF9A9DA5); ci(c, 50, 50, 12, 0xFF3B3C41); ci(c, 50, 50, 6.5f, 0xFFBABDC4); break;
            case "files":
                fill(0xFFFFFFFF); c.drawRect(0, 0, 100, 100, P);
                rr(c, 17, 26, 46, 44, 5, 0xFF4DB0FF); rr(c, 17, 34, 83, 74, 6, 0xFF1E8CF7); break;
            case "appstore":
                grad(c, 0xFF2FC1FC, 0xFF1A5CF0);
                ln(c, 50, 24, 30, 70, 7, 0xFFFFFFFF); ln(c, 50, 24, 70, 70, 7, 0xFFFFFFFF); ln(c, 36, 58, 66, 58, 6, 0xFFFFFFFF); ln(c, 24, 76, 40, 76, 6, 0xFFFFFFFF); break;
            case "notes":
                fill(0xFFFFFFFF); c.drawRect(0, 0, 100, 100, P); rr(c, 0, 0, 100, 27, 0, 0xFFFFD60A);
                for (int i = 0; i < 4; i++) ln(c, 12, 43 + i * 14, 88, 43 + i * 14, 1.6f, 0xFFE1E1E5); break;
            case "clock":
                fill(0xFF000000); c.drawRect(0, 0, 100, 100, P); ci(c, 50, 50, 43, 0xFFFFFFFF);
                for (int i = 0; i < 12; i++) { c.save(); c.rotate(i * 30, 50, 50); ln(c, 50, 11, 50, i % 3 == 0 ? 19 : 16, 2.2f, 0xFF1C1C1E); c.restore(); }
                ln(c, 50, 50, 50, 28, 4, 0xFF1C1C1E); ln(c, 50, 50, 68, 58, 3.4f, 0xFF1C1C1E); ln(c, 50, 58, 50, 17, 1.6f, 0xFFFF9500); ci(c, 50, 50, 3, 0xFFFF9500); break;
            case "calendar":
                fill(0xFFFFFFFF); c.drawRect(0, 0, 100, 100, P);
                text(c, calDay, 50, 29, 15, 0xFFFF3B30, Typeface.create("sans-serif-medium", Typeface.NORMAL));
                text(c, calNum, 50, 82, 56, 0xFF1C1C1E, Typeface.create("sans-serif-light", Typeface.NORMAL)); break;
            case "music":
                grad(c, 0xFFFB5C74, 0xFFFA233B);
                ci(c, 40, 69, 11, 0xFFFFFFFF); ln(c, 50, 68, 50, 27, 6, 0xFFFFFFFF); poly(c, 0xFFFFFFFF, 50, 26, 74, 34, 74, 47, 50, 39); break;
            case "weather":
                grad(c, 0xFF4AA8FF, 0xFF1D5FD8);
                ci(c, 40, 38, 17, 0xFFFFCC00);
                ci(c, 40, 68, 13, 0xFFFFFFFF); ci(c, 58, 60, 17, 0xFFFFFFFF); ci(c, 74, 70, 11, 0xFFFFFFFF); rr(c, 40, 64, 74, 81, 8, 0xFFFFFFFF); break;
            case "reminders":
                fill(0xFFFFFFFF); c.drawRect(0, 0, 100, 100, P);
                int[] rc = {0xFFFF9500, 0xFF007AFF, 0xFFFF3B30};
                for (int i = 0; i < 3; i++) { stroke(rc[i], 3); c.drawCircle(25, 27 + i * 23, 6.5f, P); ln(c, 40, 27 + i * 23, 86, 27 + i * 23, 1.6f, 0xFFE1E1E5); } break;
            case "books":
                grad(c, 0xFFFFA83D, 0xFFFF7A00);
                poly(c, 0xFFFFFFFF, 50, 34, 24, 28, 24, 72, 50, 78); poly(c, 0xFFFFFFFF, 50, 34, 76, 28, 76, 72, 50, 78); break;
            case "stocks":
                fill(0xFF000000); c.drawRect(0, 0, 100, 100, P);
                PA.reset(); PA.moveTo(14, 70); PA.lineTo(34, 52); PA.lineTo(48, 60); PA.lineTo(66, 34); PA.lineTo(86, 24);
                stroke(0xFF30D158, 4.5f); c.drawPath(PA, P); ln(c, 12, 82, 88, 82, 1.5f, 0x55FFFFFF); break;
            default: grad(c, 0xFFBBBBBB, 0xFF777777);
        }
        c.restore();
    }
}
