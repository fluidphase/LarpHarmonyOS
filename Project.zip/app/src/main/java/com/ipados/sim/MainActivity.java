package com.ipados.sim;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

public class MainActivity extends Activity {
    FrameLayout root;
    HomeView home;
    LockView lock;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.init(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        hideBars();
        InstallView v = new InstallView(this, this::showBoot);
        root.addView(v, new FrameLayout.LayoutParams(-1, -1));
    }

    void hideBars() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
    }

    @Override public void onWindowFocusChanged(boolean f) { super.onWindowFocusChanged(f); if (f) hideBars(); }

    void showBoot() {
        final View old = root.getChildAt(0);
        BootView bv = new BootView(this, this::showLock);
        root.addView(bv, new FrameLayout.LayoutParams(-1, -1));
        bv.setAlpha(0f);
        bv.animate().alpha(1f).setDuration(350).withEndAction(() -> root.removeView(old));
    }

    void showLock() {
        final View boot = root.getChildAt(0);
        home = new HomeView(this);
        root.addView(home, 0, new FrameLayout.LayoutParams(-1, -1));
        lock = new LockView(this, this::unlock);
        lock.setAlpha(0f);
        root.addView(lock, new FrameLayout.LayoutParams(-1, -1));
        lock.animate().alpha(1f).setDuration(700).withEndAction(() -> root.removeView(boot));
    }

    void unlock() {
        home.setScaleX(1.1f); home.setScaleY(1.1f);
        home.animate().scaleX(1f).scaleY(1f).setDuration(500).setInterpolator(new DecelerateInterpolator(2f)).start();
        lock.animate().translationY(-root.getHeight()).alpha(0f).setDuration(380).setInterpolator(new DecelerateInterpolator(1.5f))
                .withEndAction(() -> { root.removeView(lock); lock = null; }).start();
    }

    @Override public void onBackPressed() { if (home != null && lock == null) home.handleBack(); }
}
