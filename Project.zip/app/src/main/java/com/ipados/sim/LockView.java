package com.ipados.sim;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

public class LockView extends View {
    final Runnable unlock;
    Bitmap wp;
    float downY, bounce;
    boolean dragging, leaving;
    VelocityTracker vt;
    final Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG);
    final Runnable ticker = new Runnable() { public void run() { invalidate(); postDelayed(this, 1000); } };

    public LockView(Context c, Runnable unlock) { super(c); this.unlock = unlock; }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(ticker); }
    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); removeCallbacks(ticker); }
    @Override protected void onSizeChanged(int w, int h, int ow, int oh) { wp = Ui.wallpaper(w, h); }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawBitmap(wp, null, new RectF(0, 0, w, h), bp);
        c.drawColor(0x22000000);
        Ui.statusBar(c, w, false, 0xFFFFFFFF);
        float cx = w / 2f;
        // lock glyph
        Paint s = Ui.p(0xFFFFFFFF); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(Ui.dp(1.8f));
        c.drawArc(cx - Ui.dp(5), Ui.dp(20), cx + Ui.dp(5), Ui.dp(36), 180, 180, false, s);
        s.setStyle(Paint.Style.FILL); c.drawRoundRect(cx - Ui.dp(8), Ui.dp(28), cx + Ui.dp(8), Ui.dp(42), Ui.dp(3), Ui.dp(3), s);
        float ty = Math.max(h * 0.2f, Ui.dp(92));
        c.drawText(Ui.fmt("EEEE, MMMM d"), cx, ty, Ui.tx(0xDDFFFFFF, 22, Ui.MED, Paint.Align.CENTER));
        c.drawText(Ui.fmt("h:mm"), cx, ty + Ui.dp(100), Ui.tx(0xF2FFFFFF, 100, Ui.THIN, Paint.Align.CENTER));
        // left widgets
        float wx = Ui.dp(34), wy = h * 0.62f;
        c.drawText(Ui.fmt("EEE MMM d").toUpperCase(), wx, wy - Ui.dp(14), Ui.tx(0xCCFFFFFF, 12, Ui.MED, Paint.Align.LEFT));
        for (int i = 0; i < 3; i++) {
            float rx = wx + Ui.dp(22) + i * Ui.dp(58);
            Ui.ring(c, rx, wy + Ui.dp(24), Ui.dp(20), i == 0 ? 1f : (i == 1 ? .72f : .45f), 0xFFFFFFFF, 3.5f);
            c.drawText(i == 0 ? "100" : (i == 1 ? "72" : "45"), rx, wy + Ui.dp(29), Ui.tx(0xFFFFFFFF, 13, Ui.MED, Paint.Align.CENTER));
        }
        // swipe hint
        float by = h - Ui.dp(14) + bounce;
        c.drawText("Swipe up to open", cx, h - Ui.dp(32) + bounce, Ui.tx(0xB3FFFFFF, 13.5f, Ui.MED, Paint.Align.CENTER));
        Paint pill = Ui.p(0xFFFFFFFF);
        c.drawRoundRect(cx - Ui.dp(70), by - Ui.dp(5), cx + Ui.dp(70), by, Ui.dp(3), Ui.dp(3), pill);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (leaving) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downY = e.getRawY(); dragging = true; vt = VelocityTracker.obtain(); vt.addMovement(e); return true;
            case MotionEvent.ACTION_MOVE:
                vt.addMovement(e);
                float dy = e.getRawY() - downY;
                setTranslationY(dy < 0 ? dy : dy * 0.12f);
                return true;
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL:
                vt.addMovement(e); vt.computeCurrentVelocity(1000);
                float vy = vt.getYVelocity(); vt.recycle();
                float ty = getTranslationY();
                if (-ty > getHeight() * 0.18f || vy < -1400) { leaving = true; unlock.run(); }
                else if (Math.abs(ty) < Ui.dp(8) && e.getActionMasked() == MotionEvent.ACTION_UP) hint();
                else springBack();
                return true;
        }
        return true;
    }

    void springBack() {
        ValueAnimator a = ValueAnimator.ofFloat(getTranslationY(), 0);
        a.setDuration(520); a.setInterpolator(new Ui.Spring());
        a.addUpdateListener(v -> setTranslationY((float) v.getAnimatedValue()));
        a.start();
    }

    void hint() {
        ValueAnimator a = ValueAnimator.ofFloat(0, 1); a.setDuration(700);
        a.addUpdateListener(v -> { float t = (float) v.getAnimatedValue(); bounce = -Ui.dp(26) * (float) Math.sin(Math.PI * t) * (1 - t * 0.4f); invalidate(); });
        a.start();
    }
}
