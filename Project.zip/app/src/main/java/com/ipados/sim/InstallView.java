package com.ipados.sim;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.LinearInterpolator;

public class InstallView extends View {
    final Runnable done;
    final RectF btn = new RectF();
    float prog = -1, pressed = 0;
    final Paint p = Ui.p(0);

    public InstallView(Context c, Runnable done) { super(c); this.done = done; }

    @Override protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        c.drawColor(0xFF000000);
        float cx = w / 2f, s = Math.min(Ui.dp(120), h * 0.28f), top = h * 0.14f;
        Icons.draw(c, "ipados", cx - s / 2, top, s);
        c.drawText("iPadOS", cx, top + s + Ui.dp(48), Ui.tx(0xFFFFFFFF, 34, Ui.BOLD, Paint.Align.CENTER));
        c.drawText("Version 17.0  \u2022  4.2 GB", cx, top + s + Ui.dp(76), Ui.tx(0xFF8E8E93, 15, Ui.REG, Paint.Align.CENTER));
        float bw = Ui.dp(280), bh = Ui.dp(52), by = h - Ui.dp(40) - bh - h * 0.08f;
        btn.set(cx - bw / 2, by, cx + bw / 2, by + bh);
        if (prog < 0) {
            p.setColor(pressed > 0 ? 0xFF0A6FD8 : 0xFF0A84FF);
            c.drawRoundRect(btn, bh / 2, bh / 2, p);
            c.drawText("Install", cx, by + bh / 2 + Ui.dp(6), Ui.tx(0xFFFFFFFF, 18, Ui.MED, Paint.Align.CENTER));
        } else {
            p.setColor(0xFF2C2C2E); c.drawRoundRect(btn, Ui.dp(4), Ui.dp(4), p);
            RectF r = new RectF(btn.left, btn.centerY() - Ui.dp(3), btn.left + bw * prog, btn.centerY() + Ui.dp(3));
            RectF t = new RectF(btn.left, btn.centerY() - Ui.dp(3), btn.right, btn.centerY() + Ui.dp(3));
            p.setColor(0xFF2C2C2E); c.drawRoundRect(t, Ui.dp(3), Ui.dp(3), p);
            p.setColor(0xFF0A84FF); c.drawRoundRect(r, Ui.dp(3), Ui.dp(3), p);
            String st = prog < 0.3f ? "Preparing\u2026" : prog < 0.85f ? "Installing iPadOS\u2026" : "Finishing up\u2026";
            c.drawText(st + " " + (int) (prog * 100) + "%", cx, btn.centerY() - Ui.dp(18), Ui.tx(0xFFAEAEB2, 14, Ui.REG, Paint.Align.CENTER));
        }
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        if (prog >= 0) return true;
        boolean in = btn.contains(e.getX(), e.getY());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: pressed = in ? 1 : 0; invalidate(); break;
            case MotionEvent.ACTION_UP:
                if (pressed > 0 && in) start();
                pressed = 0; invalidate(); break;
            case MotionEvent.ACTION_CANCEL: pressed = 0; invalidate(); break;
        }
        return true;
    }

    final android.os.Handler hd = new android.os.Handler(android.os.Looper.getMainLooper());
    final java.util.Random rnd = new java.util.Random();

    void start() { prog = 0; invalidate(); hd.postDelayed(this::step, 900); }

    void step() {
        if (prog >= 1f) { invalidate(); hd.postDelayed(done, 900); return; }
        prog = Math.min(1f, prog + 0.006f + rnd.nextFloat() * 0.032f);   // uneven jumps
        invalidate();
        long delay = 110 + rnd.nextInt(560);
        if (rnd.nextFloat() < 0.15f) delay += 1300 + rnd.nextInt(2200);   // random stalls
        hd.postDelayed(this::step, delay);
    }

    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); hd.removeCallbacksAndMessages(null); }
}
