package com.ipados.sim;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;

public class HomeView extends View {
    static final int COLS = 7, ROWS = 4, LABEL_DP = 18;

    static class App {
        String id, name; int page; boolean removed, dock; float cx, top, sz, press = 1f, phase;
    }

    final ArrayList<App> apps = new ArrayList<>(), dock = new ArrayList<>();
    final Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG), fp = Ui.p(0);
    Bitmap wp;
    int W, H, pages = 2, slop;
    float iconSz, dockSz, cellW, cellH, gridTop, dockTop, dockBottom, vPad, hPad, label;
    final RectF wWeather = new RectF(), wCal = new RectF(), wBat = new RectF(), dockRect = new RectF(), doneBtn = new RectF();

    float pageF = 0, startPage, downX, downY, openT = 0;
    boolean moved, jiggle, lpFired, closing;
    App pressed, openApp;
    RectF ir = new RectF();
    ValueAnimator pageAnim, openAnim, menuAnim;
    VelocityTracker vt;
    long lastSec = -1;
    // Graphics Accelerator + fake low-FPS mode
    float dragDx;
    float gfxT = 1f; final RectF gfxToggle = new RectF(); ValueAnimator gfxAnim;
    Bitmap lagBmp; Canvas lagCv; long nextFrame; boolean lastAnim, capturing; int fakeFps = 60;
    // Control Center
    float ccT = 0f; boolean ccOpen, ccDrag, ccPending, ccDown; ValueAnimator ccAnim; Bitmap ccSnap; int sliderDrag = -1;
    float brightness = 0.8f, volume = 0.55f;
    final float[] tileT = new float[11]; final boolean[] tileOn = new boolean[11];
    final RectF[] tiles = new RectF[11]; final RectF ccPanel = new RectF(); RectF mConn = new RectF(), mMedia = new RectF(), sB = new RectF(), sV = new RectF();
    final Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Runnable clk = new Runnable() { public void run() { invalidate(); postDelayed(this, 1000); } };
    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); post(clk); }
    @Override protected void onDetachedFromWindow() { super.onDetachedFromWindow(); removeCallbacks(clk); }

    // context menu
    App menuApp; String[] menuItems; final RectF menuRect = new RectF(); float menuT = 0;
    static final float ROW = 46, SEP = 6;

    void add(String id, String name, int page, boolean dk) {
        App a = new App(); a.id = id; a.name = name; a.page = page; a.dock = dk; a.phase = (float) (Math.random() * 6.28);
        (dk ? dock : apps).add(a);
    }

    public HomeView(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        add("messages", "Messages", 0, true); add("facetime", "FaceTime", 0, true); add("mail", "Mail", 0, true);
        add("safari", "Safari", 0, true); add("photos", "Photos", 0, true); add("maps", "Maps", 0, true);
        add("camera", "Camera", 0, true); add("settings", "Settings", 0, true); add("files", "Files", 0, true);
        add("appstore", "App Store", 0, true);
        String[][] g0 = {{"calendar", "Calendar"}, {"clock", "Clock"}, {"notes", "Notes"}, {"reminders", "Reminders"}, {"home", "Home"}, {"findmy", "Find My"},
                {"contacts", "Contacts"}, {"books", "Books"}, {"podcasts", "Podcasts"}, {"tv", "TV"}, {"news", "News"}, {"stocks", "Stocks"},
                {"weather", "Weather"}, {"tips", "Tips"}, {"calculator", "Calculator"}, {"gfx", "Graphics Accelerator"}};
        String[][] g1 = {{"music", "Music"}, {"voicememos", "Voice Memos"}, {"measure", "Measure"}, {"compass", "Compass"}, {"wallet", "Wallet"},
                {"health", "Health"}, {"numbers", "Numbers"}, {"keynote", "Keynote"}, {"imovie", "iMovie"}};
        tileOn[2] = true; tileOn[3] = true; tileT[2] = 1f; tileT[3] = 1f;
        for (String[] a : g0) add(a[0], a[1], 0, false);
        for (String[] a : g1) add(a[0], a[1], 1, false);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w; H = h; wp = Ui.wallpaper(w, h); wpBlur = blur(wp, 3);
        label = Ui.dp(LABEL_DP);
        gridTop = Ui.dp(44);
        dockSz = Math.min(Ui.dp(64), W / (dock.size() + 4f));
        float dockH = dockSz + Ui.dp(20);
        dockBottom = H - Ui.dp(10); dockTop = dockBottom - dockH;
        float gridBottom = dockTop - Ui.dp(26);
        cellW = W / (float) COLS; cellH = (gridBottom - gridTop) / ROWS;
        iconSz = Math.min(cellW * 0.58f, (cellH - label) * 0.82f);
        vPad = (cellH - iconSz - label) / 2; hPad = (cellW - iconSz) / 2;
        wRect(wWeather, 0, 0, 3, 2); wRect(wCal, 3, 0, 2, 2); wRect(wBat, 5, 0, 2, 1);
        float gap = dockSz * 0.28f, total = dock.size() * dockSz + (dock.size() - 1) * gap, x0 = (W - total) / 2;
        for (int i = 0; i < dock.size(); i++) { App a = dock.get(i); a.sz = dockSz; a.cx = x0 + i * (dockSz + gap) + dockSz / 2; a.top = dockTop + Ui.dp(10); }
        dockRect.set(x0 - Ui.dp(16), dockTop, x0 + total + Ui.dp(16), dockBottom);
        doneBtn.set(W - Ui.dp(92), Ui.dp(30), W - Ui.dp(16), Ui.dp(62));
        layoutApps();
    }

    void wRect(RectF r, int col, int row, int cw, int ch) {
        r.set(col * cellW + hPad, gridTop + row * cellH + vPad, (col + cw) * cellW - hPad, gridTop + (row + ch) * cellH - vPad - label);
    }

    void layoutApps() {
        boolean[][] occ = new boolean[ROWS][COLS];
        for (int r = 0; r < 2; r++) for (int c = 0; c < 5; c++) occ[r][c] = true;
        occ[0][5] = occ[0][6] = true;
        for (int pg = 0; pg < pages; pg++) {
            int r = 0, c = 0;
            for (App a : apps) {
                if (a.page != pg || a.removed) continue;
                while (pg == 0 && r < ROWS && occ[r][c]) { c++; if (c == COLS) { c = 0; r++; } }
                if (r >= ROWS) break;
                a.sz = iconSz; a.cx = c * cellW + cellW / 2; a.top = gridTop + r * cellH + vPad;
                c++; if (c == COLS) { c = 0; r++; }
            }
        }
    }

    RectF screenRect(App a) {
        float sh = a.dock ? 0 : (a.page - pageF) * W;
        return new RectF(a.cx - a.sz / 2 + sh, a.top, a.cx + a.sz / 2 + sh, a.top + a.sz);
    }

    App hit(float x, float y) {
        for (App a : dock) { RectF r = screenRect(a); r.inset(-Ui.dp(6), -Ui.dp(6)); if (r.contains(x, y)) return a; }
        int pg = Math.round(pageF);
        for (App a : apps) {
            if (a.removed || a.page != pg) continue;
            RectF r = screenRect(a); r.inset(-Ui.dp(6), -Ui.dp(4)); r.bottom += label;
            if (r.contains(x, y)) return a;
        }
        return null;
    }

    // ---------------------------------------------------------------- drawing
    @Override protected void onDraw(Canvas c) {
        if (wp == null) return;
        long now = SystemClock.uptimeMillis();
        if (Ui.gfx) lastAnim = render(c, now, true);
        else {   // accelerator off: only produce a fresh frame every ~100-370 ms
            if (lagBmp == null || lagBmp.getWidth() != W || lagBmp.getHeight() != H) { lagBmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888); lagCv = new Canvas(lagBmp); nextFrame = 0; }
            if (now >= nextFrame) {
                lagBmp.eraseColor(0); fakeFps = 3 + (int) (Math.random() * 10);
                lastAnim = render(lagCv, now, true);
                nextFrame = now + 90 + (long) (Math.random() * 280);
            }
            c.drawBitmap(lagBmp, 0, 0, null);
        }
        if (lastAnim) { if (Ui.gfx) postInvalidateOnAnimation(); else postInvalidateDelayed(24); }
    }

    boolean render(Canvas c, long now, boolean overlays) {
        if (now / 1000 != lastSec) { lastSec = now / 1000; Icons.calDay = Ui.fmt("EEEE"); Icons.calNum = Ui.fmt("d"); }
        boolean anim = jiggle || !Ui.gfx || (pageAnim != null && pageAnim.isRunning()) || (openAnim != null && openAnim.isRunning())
                || (menuAnim != null && menuAnim.isRunning()) || (ccAnim != null && ccAnim.isRunning()) || (gfxAnim != null && gfxAnim.isRunning());
        float tc = Math.max(0, openT);
        c.save();
        float s = 1 + 0.07f * Math.min(1, tc);
        c.scale(s, s, W / 2f, H / 2f);
        if (drawHomeBody(c, now)) anim = true;
        if (tc > 0.001f && snap != null) {
            bp.setAlpha((int) (255 * Math.min(1f, tc * 1.6f))); c.drawBitmap(snap, null, new RectF(0, 0, W, H), bp); bp.setAlpha(255);
            fp.setColor(Color.argb((int) (70 * Math.min(1f, tc)), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        }
        if (menuApp != null) { drawMenu(c); anim = true; }
        c.restore();
        if (tc > 0.001f) drawWindow(c);
        if (overlays) {
            if (ccT > 0.001f && ccSnap != null && drawCC(c)) anim = true;
            if (brightness < 0.99f) { fp.setColor(Color.argb((int) ((1 - brightness) * 150), 0, 0, 0)); c.drawRect(0, 0, W, H, fp); }
            if (!Ui.gfx) c.drawText("FPS: " + fakeFps, W / 2f, Ui.dp(21), Ui.tx(0xFFFFFFFF, 11.5f, Ui.MED, Paint.Align.CENTER));
        }
        return anim;
    }

    boolean drawHomeBody(Canvas c, long now) {
        boolean anim = jiggle || (pageAnim != null && pageAnim.isRunning());
        if (Ui.gfx) { float off = -pageF * Ui.dp(26); c.drawBitmap(wp, null, new RectF(off - Ui.dp(30), 0, W + Ui.dp(30) + off, H), bp); c.drawColor(0x1A000000); }
        else c.drawColor(0xFF000000);
        Ui.statusBar(c, W, true, 0xFFFFFFFF);
        int sv = c.save();
        for (int pg = 0; pg < pages; pg++) {
            float x = (pg - pageF) * W;
            if (Math.abs(x) >= W) continue;
            c.save(); c.translate(x, 0);
            if (pg == 0) { drawWeather(c, wWeather); drawCalendar(c, wCal); drawBattery(c, wBat); }
            for (App a : apps) if (a.page == pg && !a.removed && a != menuApp) { if (drawApp(c, a, now, true)) anim = true; }
            c.restore();
        }
        // page dots
        for (int i = 0; i < pages; i++) {
            Paint d = Ui.p(0xFFFFFFFF); d.setAlpha(Math.abs(i - pageF) < 0.5f ? 255 : 110);
            c.drawCircle(W / 2f + (i - (pages - 1) / 2f) * Ui.dp(14), dockTop - Ui.dp(12), Ui.dp(3.2f), d);
        }
        // dock
        if (Ui.gfx) {
            Path dpp = new Path(); dpp.addRoundRect(dockRect, Ui.dp(28), Ui.dp(28), Path.Direction.CW);
            c.save(); c.clipPath(dpp); c.drawBitmap(wpBlur, null, new RectF(0, 0, W, H), bp); fp.setColor(0x38FFFFFF); c.drawRect(dockRect, fp); c.restore();
        } else { fp.setColor(0xFF141414); c.drawRoundRect(dockRect, Ui.dp(28), Ui.dp(28), fp); }
        fp.setStyle(Paint.Style.STROKE); fp.setStrokeWidth(Ui.dp(0.6f)); fp.setColor(0x33FFFFFF); c.drawRoundRect(dockRect, Ui.dp(28), Ui.dp(28), fp); fp.setStyle(Paint.Style.FILL);
        for (App a : dock) if (a != menuApp) { if (drawApp(c, a, now, false)) anim = true; }
        if (jiggle) {
            fp.setColor(0x66000000); c.drawRoundRect(doneBtn, Ui.dp(16), Ui.dp(16), fp);
            c.drawText("Done", doneBtn.centerX(), doneBtn.centerY() + Ui.dp(5), Ui.tx(0xFFFFFFFF, 15, Ui.MED, Paint.Align.CENTER));
        }
        c.restoreToCount(sv);
        return anim;
    }

    Bitmap snap, wpBlur;

    static Bitmap blur(Bitmap src, int n) {
        Bitmap cur = src;
        for (int i = 0; i < n; i++) cur = Bitmap.createScaledBitmap(cur, Math.max(2, cur.getWidth() / 2), Math.max(2, cur.getHeight() / 2), true);
        for (int i = 0; i < n; i++) cur = Bitmap.createScaledBitmap(cur, cur.getWidth() * 2, cur.getHeight() * 2, true);
        return cur;
    }

    void captureSnap() {
        if (W <= 0) return;
        Bitmap b = Bitmap.createBitmap(Math.max(2, W / 4), Math.max(2, H / 4), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b); cv.scale(b.getWidth() / (float) W, b.getHeight() / (float) H);
        capturing = true; drawHomeBody(cv, SystemClock.uptimeMillis()); capturing = false;
        snap = blur(b, 3);
    }

    boolean drawApp(Canvas c, App a, long now, boolean labels) {
        if (a == openApp && (openT > 0.001f || capturing)) return false;
        float target = (a == pressed && !moved && openApp == null && menuApp == null) ? 0.9f : 1f;
        boolean busy = false;
        if (Math.abs(a.press - target) > 0.002f) { a.press += (target - a.press) * 0.35f; busy = true; }
        float rot = jiggle ? (float) Math.sin(now / 62.0 + a.phase) * 1.7f : 0;
        float cx = a.cx, cy = a.top + a.sz / 2;
        c.save(); c.scale(a.press, a.press, cx, cy); if (rot != 0) c.rotate(rot, cx, cy);
        Icons.draw(c, a.id, cx - a.sz / 2, a.top, a.sz);
        if (a.press < 0.995f) { fp.setColor(Color.argb((int) ((1 - a.press) * 380), 0, 0, 0)); c.drawRoundRect(cx - a.sz / 2, a.top, cx + a.sz / 2, a.top + a.sz, a.sz * 0.225f, a.sz * 0.225f, fp); }
        if (jiggle) {
            fp.setColor(0xFFB8B8BE); c.drawCircle(cx - a.sz / 2 + Ui.dp(2), a.top + Ui.dp(2), Ui.dp(9), fp);
            fp.setColor(0xFF2C2C2E); c.drawRoundRect(cx - a.sz / 2 - Ui.dp(2.5f), a.top + Ui.dp(0.9f), cx - a.sz / 2 + Ui.dp(6.5f), a.top + Ui.dp(3.1f), Ui.dp(1), Ui.dp(1), fp);
        }
        c.restore();
        if (labels) { Paint lt = Ui.tx(0xFFFFFFFF, 11.5f, Ui.REG, Paint.Align.CENTER); float mw = lt.measureText(a.name), mx = cellW - Ui.dp(8); if (mw > mx) lt.setTextSize(lt.getTextSize() * mx / mw); c.drawText(a.name, cx, a.top + a.sz + Ui.dp(14), lt); }
        return busy;
    }

    void card(Canvas c, RectF r, int col) { fp.setStyle(Paint.Style.FILL); fp.setColor(col); c.drawRoundRect(r, Ui.dp(22), Ui.dp(22), fp); }
    void txt(Canvas c, String s, float x, float y, int col, float sz, Typeface f, Paint.Align al) { c.drawText(s, x, y, Ui.tx(col, sz, f, al)); }

    void drawLoading(Canvas c, RectF r) {
        card(c, r, 0xFF0F0F0F);
        fp.setColor(0xFF262626);
        c.drawRoundRect(r.left + Ui.dp(16), r.top + Ui.dp(16), r.left + r.width() * 0.45f, r.top + Ui.dp(28), Ui.dp(6), Ui.dp(6), fp);
        c.drawRoundRect(r.left + Ui.dp(16), r.top + Ui.dp(36), r.left + r.width() * 0.3f, r.top + Ui.dp(46), Ui.dp(5), Ui.dp(5), fp);
        float cx = r.centerX(), cy = r.centerY() + Ui.dp(8), rr = Math.min(Ui.dp(11), r.height() * 0.16f);
        Paint sp = Ui.p(0xFFFF2B2B); sp.setStyle(Paint.Style.STROKE); sp.setStrokeWidth(Ui.dp(2.2f)); sp.setStrokeCap(Paint.Cap.ROUND);
        float ang = (SystemClock.uptimeMillis() % 900) / 900f * 360f;
        c.drawArc(cx - rr, cy - rr, cx + rr, cy + rr, ang, 100, false, sp);
        if (r.height() > Ui.dp(70)) txt(c, "Loading\u2026", cx, cy + rr + Ui.dp(18), 0xFFFFFFFF, 12, Ui.REG, Paint.Align.CENTER);
    }

    void drawWeather(Canvas c, RectF r) {
        if (!Ui.gfx) { drawLoading(c, r); return; }
        card(c, r, 0xD91C1C1E);
        float u = Math.max(0.5f, Math.min(r.height() / Ui.dp(160), r.width() / Ui.dp(300))), x = r.left + Ui.dp(16) * u, y = r.top;
        txt(c, "Cupertino", x, y + Ui.dp(26) * u, 0xFFFFFFFF, 15 * u, Ui.BOLD, Paint.Align.LEFT);
        txt(c, "72\u00B0", x, y + Ui.dp(72) * u, 0xFFFFFFFF, 44 * u, Ui.LIGHT, Paint.Align.LEFT);
        fp.setColor(0xFFFFCC00); c.drawCircle(r.right - Ui.dp(38) * u, y + Ui.dp(34) * u, Ui.dp(11) * u, fp);
        txt(c, "Sunny", r.right - Ui.dp(16) * u, y + Ui.dp(64) * u, 0xFFFFFFFF, 13 * u, Ui.MED, Paint.Align.RIGHT);
        txt(c, "H:78\u00B0  L:61\u00B0", r.right - Ui.dp(16) * u, y + Ui.dp(82) * u, 0xCCFFFFFF, 12 * u, Ui.REG, Paint.Align.RIGHT);
        String[] t = {"Now", "10 AM", "11 AM", "12 PM", "1 PM"}; int[] d = {72, 74, 76, 77, 77};
        float cw = (r.width() - Ui.dp(32) * u) / 5;
        for (int i = 0; i < 5; i++) {
            float cx = x + cw * i + cw / 2;
            txt(c, t[i], cx, y + Ui.dp(116) * u, 0xCCFFFFFF, 11 * u, Ui.MED, Paint.Align.CENTER);
            fp.setColor(0xFFFFCC00); c.drawCircle(cx, y + Ui.dp(130) * u, Ui.dp(5.5f) * u, fp);
            txt(c, d[i] + "\u00B0", cx, y + Ui.dp(150) * u, 0xFFFFFFFF, 12.5f * u, Ui.MED, Paint.Align.CENTER);
        }
    }

    void drawCalendar(Canvas c, RectF r) {
        if (!Ui.gfx) { drawLoading(c, r); return; }
        card(c, r, 0xD91C1C1E);
        float u = Math.max(0.5f, Math.min(r.height() / Ui.dp(160), r.width() / Ui.dp(160))), x = r.left + Ui.dp(14) * u;
        txt(c, Ui.fmt("EEEE").toUpperCase(), x, r.top + Ui.dp(26) * u, 0xFFFF453A, 12 * u, Ui.BOLD, Paint.Align.LEFT);
        txt(c, Ui.fmt("d"), x, r.top + Ui.dp(70) * u, 0xFFFFFFFF, 44 * u, Ui.LIGHT, Paint.Align.LEFT);
        String[] ev = {"Design review", "Lunch with Marcel", "Timesheet deadline"}; String[] tm = {"10:30 AM", "12:00 PM", "5:00 PM"};
        int[] col = {0xFF0A84FF, 0xFF30D158, 0xFFFF9F0A};
        for (int i = 0; i < 3; i++) {
            float y = r.top + Ui.dp(92) * u + i * Ui.dp(22) * u;
            fp.setColor(col[i]); c.drawRoundRect(x, y - Ui.dp(11) * u, x + Ui.dp(3) * u, y + Ui.dp(7) * u, 2, 2, fp);
            txt(c, ev[i], x + Ui.dp(9) * u, y - Ui.dp(1) * u, 0xFFFFFFFF, 11 * u, Ui.MED, Paint.Align.LEFT);
            txt(c, tm[i], x + Ui.dp(9) * u, y + Ui.dp(8) * u, 0x99FFFFFF, 9 * u, Ui.REG, Paint.Align.LEFT);
        }
    }

    void drawBattery(Canvas c, RectF r) {
        if (!Ui.gfx) { drawLoading(c, r); return; }
        card(c, r, 0xD91C1C1E);
        float rad = r.height() * 0.3f;
        for (int i = 0; i < 2; i++) {
            float cx = r.left + r.width() * (0.28f + 0.44f * i), cy = r.centerY();
            Ui.ring(c, cx, cy, rad, 1f, i == 0 ? 0xFF30D158 : 0xFF30D158, 3.4f);
            Icons.fill(0xFFFFFFFF);
            c.drawRoundRect(cx - rad * 0.3f, cy - rad * 0.45f, cx + rad * 0.3f, cy + rad * 0.45f, 3, 3, Icons.P);
        }
    }

    // ---------------------------------------------------------------- context menu
    String[] extras(String id) {
        switch (id) {
            case "notes": return new String[]{"New Note", "New Checklist"};
            case "camera": return new String[]{"Take Selfie", "Record Video"};
            case "messages": case "mail": return new String[]{"New Message", "Search"};
            case "reminders": return new String[]{"New Reminder", "Add List"};
            case "safari": return new String[]{"New Tab", "New Private Tab"};
            default: return new String[]{"Open", "Search"};
        }
    }

    void showMenu(App a) {
        captureSnap();
        menuApp = a; String[] e = extras(a.id);
        menuItems = new String[]{"Remove App", "Share App", "Edit Home Screen", e[0], e[1]};
        float w = Ui.dp(250), h = ROW * Ui.d * 5 + SEP * Ui.d;
        RectF r = screenRect(a);
        float l = Math.max(Ui.dp(12), Math.min(r.left, W - w - Ui.dp(12)));
        float t = r.bottom + label + Ui.dp(6);
        if (t + h > H - Ui.dp(12)) t = Math.max(Ui.dp(12), r.top - h - Ui.dp(10));
        menuRect.set(l, t, l + w, t + h);
        menuAnim(0, 1, 280);
    }

    void menuAnim(float from, float to, int ms) {
        if (menuAnim != null) menuAnim.cancel();
        menuAnim = ValueAnimator.ofFloat(from, to); menuAnim.setDuration(ms); menuAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        menuAnim.addUpdateListener(v -> { menuT = (float) v.getAnimatedValue(); invalidate(); });
        if (to == 0) menuAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator an) { cn = true; }
            @Override public void onAnimationEnd(Animator an) { if (!cn) { menuApp = null; } } });
        menuAnim.start();
    }

    void drawMenu(Canvas c) {
        if (snap != null) { bp.setAlpha((int) (255 * menuT)); c.drawBitmap(snap, null, new RectF(0, 0, W, H), bp); bp.setAlpha(255); }
        fp.setColor(Color.argb((int) (70 * menuT), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        App a = menuApp; RectF r = screenRect(a);
        c.save(); float s = 1 + 0.08f * menuT; c.scale(s, s, r.centerX(), r.centerY()); Icons.draw(c, a.id, r.left, r.top, r.width()); c.restore();
        c.save();
        float sc = Ui.lerp(0.5f, 1f, menuT);
        c.scale(sc, sc, r.centerX() < W / 2f ? menuRect.left : menuRect.right, menuRect.top < r.top ? menuRect.bottom : menuRect.top);
        c.saveLayerAlpha(menuRect.left - 4, menuRect.top - 4, menuRect.right + 4, menuRect.bottom + 4, (int) (255 * Math.min(1, menuT * 1.4f)));
        fp.setColor(0xF0F0F0F5); c.drawRoundRect(menuRect, Ui.dp(16), Ui.dp(16), fp);
        float rh = Ui.dp(ROW), y = menuRect.top;
        for (int i = 0; i < 5; i++) {
            if (i == 3) { fp.setColor(0xFFD4D4DA); c.drawRect(menuRect.left, y, menuRect.right, y + Ui.dp(SEP), fp); y += Ui.dp(SEP); }
            int col = i == 0 ? 0xFFFF3B30 : 0xFF1C1C1E;
            txt(c, menuItems[i], menuRect.left + Ui.dp(16), y + rh / 2 + Ui.dp(5.5f), col, 16.5f, Ui.REG, Paint.Align.LEFT);
            glyph(c, i, menuRect.right - Ui.dp(26), y + rh / 2, col);
            if (i != 2 && i != 4) { fp.setColor(0x1F000000); c.drawRect(menuRect.left, y + rh - 1, menuRect.right, y + rh, fp); }
            y += rh;
        }
        c.restore(); c.restore();
    }

    void glyph(Canvas c, int i, float cx, float cy, int col) {
        Paint s = Ui.p(col); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(Ui.dp(1.5f)); s.setStrokeCap(Paint.Cap.ROUND);
        float u = Ui.dp(1);
        if (i == 0) { c.drawCircle(cx, cy, 8 * u, s); c.drawLine(cx - 4 * u, cy, cx + 4 * u, cy, s); }
        else if (i == 1) { c.drawRoundRect(cx - 6 * u, cy - 3 * u, cx + 6 * u, cy + 8 * u, 2 * u, 2 * u, s); c.drawLine(cx, cy - 9 * u, cx, cy + 3 * u, s); c.drawLine(cx, cy - 9 * u, cx - 3 * u, cy - 6 * u, s); c.drawLine(cx, cy - 9 * u, cx + 3 * u, cy - 6 * u, s); }
        else if (i == 2) { c.drawRoundRect(cx - 5 * u, cy - 8 * u, cx + 5 * u, cy + 8 * u, 2 * u, 2 * u, s); c.drawLine(cx - 2 * u, cy + 5 * u, cx + 2 * u, cy + 5 * u, s); }
        else { c.drawLine(cx - 6 * u, cy, cx + 6 * u, cy, s); c.drawLine(cx, cy - 6 * u, cx, cy + 6 * u, s); }
    }

    // ---------------------------------------------------------------- app window
    void drawWindow(Canvas c) {
        float t = openT, tc = Math.min(1f, Math.max(0f, t));
        float l = Ui.lerp(ir.left, 0, t), tp = Ui.lerp(ir.top, 0, t), r = Ui.lerp(ir.right, W, t), b = Ui.lerp(ir.bottom, H, t);
        float sh = dragDx * tc; l += sh; r += sh;
        float rad = Ui.lerp(ir.width() * 0.225f, Ui.dp(26), Math.min(1f, tc * 1.15f));
        if (tc < 0.98f) for (int i = 5; i >= 1; i--) {   // soft drop shadow
            fp.setColor(Color.argb((int) (15 * (1 - tc)), 0, 0, 0)); float g = Ui.dp(3) * i;
            c.drawRoundRect(l - g, tp - g + Ui.dp(3), r + g, b + g + Ui.dp(5), rad + g, rad + g, fp);
        }
        Path clip = new Path(); clip.addRoundRect(l, tp, r, b, rad, rad, Path.Direction.CW);
        c.save(); c.clipPath(clip);
        fp.setColor(0xFF000000); c.drawRect(l, tp, r, b, fp);
        float k = Math.max((r - l) / W, (b - tp) / H);          // app UI scales up with the window
        c.save(); c.translate((l + r) / 2, (tp + b) / 2); c.scale(k, k); c.translate(-W / 2f, -H / 2f);
        drawSkin(c, openApp); c.restore();
        float ia = 1 - Ui.cl(tc / 0.34f); ia = ia * ia * (3 - 2 * ia);
        if (ia > 0) {
            float sz = r - l;
            c.saveLayerAlpha(l, tp, r, b, (int) (255 * ia));
            Icons.draw(c, openApp.id, l, (tp + b) / 2 - sz / 2, sz);
            c.restore();
        }
        c.restore();
    }

    boolean dark(App a) { return a.id.equals("clock") || a.id.equals("stocks") || a.id.equals("camera") || a.id.equals("settings") || !Ui.gfx; }

    void drawSkin(Canvas c, App a) {
        if (a.id.equals("settings")) skinSettings(c);
        else if (a.id.equals("gfx")) skinGfx(c);
        else {
            boolean dk = dark(a);
            c.drawColor(Ui.bg(dk ? 0xFF000000 : 0xFFF2F2F7));
            txt(c, a.name, Ui.dp(32), Ui.dp(92), dk ? 0xFFFFFFFF : 0xFF000000, 34, Ui.BOLD, Paint.Align.LEFT);
            float s = Math.min(Ui.dp(110), H * 0.3f);
            Icons.draw(c, a.id, W / 2f - s / 2, H * 0.36f - s / 2 + Ui.dp(10), s);
            txt(c, "Swipe up from the bottom edge to go home", W / 2f, H * 0.36f + s / 2 + Ui.dp(52), dk ? 0xFF8E8E93 : 0xFF6C6C70, 16, Ui.REG, Paint.Align.CENTER);
        }
        Ui.statusBar(c, W, true, dark(a) ? 0xFFFFFFFF : 0xFF000000);
        fp.setColor(dark(a) ? 0xB3FFFFFF : 0x99000000); c.drawRoundRect(W / 2f - Ui.dp(70), H - Ui.dp(11), W / 2f + Ui.dp(70), H - Ui.dp(6), Ui.dp(3), Ui.dp(3), fp);
    }

    int mix(int a, int b, float t) {
        return Color.argb(255, (int) Ui.lerp(Color.red(a), Color.red(b), t), (int) Ui.lerp(Color.green(a), Color.green(b), t), (int) Ui.lerp(Color.blue(a), Color.blue(b), t));
    }

    void toggle(Canvas c, float cx, float cy, boolean on) { toggleT(c, cx, cy, on ? 1f : 0f, 0xFF39393D); }

    /** iPadOS switch; t = 0 (off) .. 1 (on), animated. */
    void toggleT(Canvas c, float cx, float cy, float t, int offCol) {
        float w = Ui.dp(51), h = Ui.dp(31), kr = h / 2 - Ui.dp(2);
        fp.setColor(mix(offCol, 0xFF34C759, Ui.cl(t))); c.drawRoundRect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, h / 2, h / 2, fp);
        float kx = Ui.lerp(cx - w / 2 + h / 2, cx + w / 2 - h / 2, t);
        fp.setColor(0x26000000); c.drawCircle(kx, cy + Ui.dp(1.2f), kr + Ui.dp(0.6f), fp);
        fp.setColor(0xFFFFFFFF); c.drawCircle(kx, cy, kr, fp);
    }

    void skinGfx(Canvas c) {
        c.drawColor(Ui.bg(0xFFF2F2F7));
        txt(c, "Graphics Accelerator", Ui.dp(40), Ui.dp(96), 0xFF000000, 34, Ui.BOLD, Paint.Align.LEFT);
        float cw = Math.min(W - Ui.dp(80), Ui.dp(560)), x = (W - cw) / 2f, y = Ui.dp(124), rh = Ui.dp(58);
        float s = Math.min(Ui.dp(64), H * 0.16f);
        Icons.draw(c, "gfx", W / 2f - s / 2, y, s); y += s + Ui.dp(22);
        fp.setColor(Ui.gfx ? 0xFFFFFFFF : 0xFF0F0F0F); c.drawRoundRect(x, y, x + cw, y + rh, Ui.dp(12), Ui.dp(12), fp);
        txt(c, "Graphics Acceleration", x + Ui.dp(18), y + rh / 2 + Ui.dp(6), 0xFF000000, 17, Ui.REG, Paint.Align.LEFT);
        float tx = x + cw - Ui.dp(18) - Ui.dp(25.5f);
        toggleT(c, tx, y + rh / 2, gfxT, Ui.gfx ? 0xFFE5E5EA : 0xFF39393D);
        gfxToggle.set(tx - Ui.dp(26), y + rh / 2 - Ui.dp(16), tx + Ui.dp(26), y + rh / 2 + Ui.dp(16));
        txt(c, "When turned off, the display runs at a very low frame rate,", x + Ui.dp(18), y + rh + Ui.dp(22), 0xFF6C6C70, 13, Ui.REG, Paint.Align.LEFT);
        txt(c, "widgets stop loading and all text turns red on a black screen.", x + Ui.dp(18), y + rh + Ui.dp(40), 0xFF6C6C70, 13, Ui.REG, Paint.Align.LEFT);
    }

    void setGfx(boolean on) {
        if (on == Ui.gfx) return;
        Ui.gfx = on; nextFrame = 0;
        performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
        if (gfxAnim != null) gfxAnim.cancel();
        gfxAnim = ValueAnimator.ofFloat(gfxT, on ? 1f : 0f); gfxAnim.setDuration(260); gfxAnim.setInterpolator(new DecelerateInterpolator(1.4f));
        gfxAnim.addUpdateListener(v -> { gfxT = (float) v.getAnimatedValue(); invalidate(); });
        gfxAnim.start();
    }

    void chev(Canvas c, float x, float y) {
        Paint p = Ui.p(0xFF6C6C70); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(Ui.dp(2)); p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(x - Ui.dp(3), y - Ui.dp(5.5f), x + Ui.dp(2), y, p); c.drawLine(x + Ui.dp(2), y, x - Ui.dp(3), y + Ui.dp(5.5f), p);
    }

    void sidebarGroup(Canvas c, float x, float w, float y, String[] names, int[] cols, String[] ids, int sel) {
        float rh = Ui.dp(44), isz = Ui.dp(29);
        fp.setColor(0xFF1C1C1E); c.drawRoundRect(x, y, x + w, y + names.length * rh, Ui.dp(12), Ui.dp(12), fp);
        for (int i = 0; i < names.length; i++) {
            float ry = y + i * rh;
            if (i == sel) { fp.setColor(0xFF0A62C6); c.drawRoundRect(x, ry, x + w, ry + rh, Ui.dp(12), Ui.dp(12), fp); }
            float ix = x + Ui.dp(12), iy = ry + (rh - isz) / 2;
            if (ids[i] != null) Icons.draw(c, ids[i], ix, iy, isz);
            else {
                fp.setColor(cols[i]); c.drawRoundRect(ix, iy, ix + isz, iy + isz, isz * 0.225f, isz * 0.225f, fp);
                if (names[i].startsWith("Display")) txt(c, "AA", ix + isz / 2, iy + isz / 2 + Ui.dp(4), 0xFFFFFFFF, 11.5f, Ui.BOLD, Paint.Align.CENTER);
                else { Paint g = Ui.p(0xFFFFFFFF); g.setStyle(Paint.Style.STROKE); g.setStrokeWidth(Ui.dp(1.6f)); c.drawCircle(ix + isz / 2, iy + isz / 2, isz * 0.24f, g); }
            }
            txt(c, names[i], x + Ui.dp(52), ry + rh / 2 + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT);
            if (i < names.length - 1 && i != sel && i + 1 != sel) { fp.setColor(0xFF2C2C2E); c.drawRect(x + Ui.dp(52), ry + rh - 1, x + w, ry + rh, fp); }
        }
    }

    void skinSettings(Canvas c) {
        c.drawColor(0xFF000000);
        float sw = Math.max(W * 0.34f, Ui.dp(270)), rh = Ui.dp(44), lx = Ui.dp(18), lw = sw - Ui.dp(36);
        sidebarGroup(c, lx, lw, Ui.dp(84), new String[]{"Display & Brightness", "Home Screen & Dock", "Accessibility", "Wallpaper", "Siri & Search", "Apple Pencil", "Touch ID & Passcode", "Battery", "Privacy & Security"},
                new int[]{0xFF0A84FF, 0xFF3D5AFE, 0xFF0A84FF, 0xFF32ADE6, 0xFF2A2A5E, 0xFF8E8E93, 0xFFFF2D55, 0xFF34C759, 0xFF0A84FF}, new String[9], 0);
        float y2 = Ui.dp(84) + 9 * rh + Ui.dp(34);
        sidebarGroup(c, lx, lw, y2, new String[]{"App Store", "Wallet & Apple Pay"}, new int[2], new String[]{"appstore", "wallet"}, -1);
        float y3 = y2 + 2 * rh + Ui.dp(34);
        sidebarGroup(c, lx, lw, y3, new String[]{"Passwords", "Mail", "Contacts", "Calendar"}, new int[]{0xFF8E8E93, 0, 0, 0}, new String[]{null, "mail", "contacts", "calendar"}, -1);
        fp.setColor(0xFF2C2C2E); c.drawRect(sw, 0, sw + 1, H, fp);
        fp.setColor(0xE61A1A1C); c.drawRect(0, 0, sw, Ui.dp(70), fp); c.drawRect(sw + 1, 0, W, Ui.dp(70), fp);
        txt(c, "Settings", sw / 2, Ui.dp(55), 0xFFFFFFFF, 17, Ui.BOLD, Paint.Align.CENTER);
        float px = sw + Ui.dp(28), pw = W - px - Ui.dp(28), cx = sw + (W - sw) / 2;
        txt(c, "Display & Brightness", cx, Ui.dp(55), 0xFFFFFFFF, 17, Ui.BOLD, Paint.Align.CENTER);
        float y = Ui.dp(92);
        y = tcard(c, px, pw, y, "Automatic", null, 0, false) + Ui.dp(28);
        fp.setColor(0xFF1C1C1E); c.drawRoundRect(px, y, px + pw, y + 2 * rh, Ui.dp(12), Ui.dp(12), fp);
        txt(c, "Text Size", px + Ui.dp(16), y + rh / 2 + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT); chev(c, px + pw - Ui.dp(18), y + rh / 2);
        fp.setColor(0xFF2C2C2E); c.drawRect(px + Ui.dp(16), y + rh - 1, px + pw, y + rh, fp);
        txt(c, "Bold Text", px + Ui.dp(16), y + rh * 1.5f + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT); toggle(c, px + pw - Ui.dp(40), y + rh * 1.5f, false);
        y += 2 * rh + Ui.dp(30);
        txt(c, "BRIGHTNESS", px + Ui.dp(16), y - Ui.dp(8), 0xFF8E8E93, 12.5f, Ui.REG, Paint.Align.LEFT);
        fp.setColor(0xFF1C1C1E); c.drawRoundRect(px, y, px + pw, y + 2 * rh, Ui.dp(12), Ui.dp(12), fp);
        float ty = y + rh / 2, tl = px + Ui.dp(54), tr = px + pw - Ui.dp(54), kx = tl + (tr - tl) * 0.74f;
        fp.setColor(0xFF48484A); c.drawRoundRect(tl, ty - Ui.dp(1.5f), tr, ty + Ui.dp(1.5f), 3, 3, fp);
        fp.setColor(0xFF0A84FF); c.drawRoundRect(tl, ty - Ui.dp(1.5f), kx, ty + Ui.dp(1.5f), 3, 3, fp);
        fp.setColor(0xFFFFFFFF); c.drawCircle(kx, ty, Ui.dp(13), fp);
        Paint sun = Ui.p(0xFF8E8E93); sun.setStyle(Paint.Style.STROKE); sun.setStrokeWidth(Ui.dp(1.4f)); c.drawCircle(px + Ui.dp(24), ty, Ui.dp(4), sun); c.drawCircle(px + pw - Ui.dp(24), ty, Ui.dp(6), sun);
        fp.setColor(0xFF2C2C2E); c.drawRect(px + Ui.dp(16), y + rh - 1, px + pw, y + rh, fp);
        txt(c, "True Tone", px + Ui.dp(16), y + rh * 1.5f + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT); toggle(c, px + pw - Ui.dp(40), y + rh * 1.5f, false);
        y += 2 * rh + Ui.dp(10);
        txt(c, "Automatically adapt iPad display based on ambient lighting conditions", px + Ui.dp(16), y + Ui.dp(10), 0xFF8E8E93, 12.5f, Ui.REG, Paint.Align.LEFT);
        txt(c, "to make colours appear consistent in different environments.", px + Ui.dp(16), y + Ui.dp(26), 0xFF8E8E93, 12.5f, Ui.REG, Paint.Align.LEFT);
        y += Ui.dp(44);
        y = tcard(c, px, pw, y, "Night Shift", "Off", 0, false) + Ui.dp(28);
        fp.setColor(0xFF1C1C1E); c.drawRoundRect(px, y, px + pw, y + 2 * rh, Ui.dp(12), Ui.dp(12), fp);
        txt(c, "Auto-Lock", px + Ui.dp(16), y + rh / 2 + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT);
        txt(c, "Never", px + pw - Ui.dp(34), y + rh / 2 + Ui.dp(5.5f), 0xFF8E8E93, 16, Ui.REG, Paint.Align.RIGHT); chev(c, px + pw - Ui.dp(18), y + rh / 2);
        fp.setColor(0xFF2C2C2E); c.drawRect(px + Ui.dp(16), y + rh - 1, px + pw, y + rh, fp);
        txt(c, "Lock / Unlock", px + Ui.dp(16), y + rh * 1.5f + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT); toggle(c, px + pw - Ui.dp(40), y + rh * 1.5f, true);
        y += 2 * rh + Ui.dp(10);
        txt(c, "Automatically lock and unlock your iPad when you close and open the iPad cover.", px + Ui.dp(16), y + Ui.dp(10), 0xFF8E8E93, 12.5f, Ui.REG, Paint.Align.LEFT);
        y += Ui.dp(52);
        txt(c, "DISPLAY", px + Ui.dp(16), y - Ui.dp(8), 0xFF8E8E93, 12.5f, Ui.REG, Paint.Align.LEFT);
        tcard(c, px, pw, y, "Display Zoom", "Standard", 0, false);
    }

    /** Single-row dark settings card with optional value + chevron, or a toggle when val == null. */
    float tcard(Canvas c, float x, float w, float y, String title, String val, int unused, boolean on) {
        float rh = Ui.dp(44);
        fp.setColor(0xFF1C1C1E); c.drawRoundRect(x, y, x + w, y + rh, Ui.dp(12), Ui.dp(12), fp);
        txt(c, title, x + Ui.dp(16), y + rh / 2 + Ui.dp(5.5f), 0xFFFFFFFF, 16, Ui.REG, Paint.Align.LEFT);
        if (val == null) toggle(c, x + w - Ui.dp(40), y + rh / 2, on);
        else { txt(c, val, x + w - Ui.dp(34), y + rh / 2 + Ui.dp(5.5f), 0xFF8E8E93, 16, Ui.REG, Paint.Align.RIGHT); chev(c, x + w - Ui.dp(18), y + rh / 2); }
        return y + rh;
    }


    // ---------------------------------------------------------------- Control Center
    RectF cell(float px, float py, float cs, float g, int col, int row, int cw, int ch) {
        float l = px + col * (cs + g), t = py + row * (cs + g);
        return new RectF(l, t, l + cw * cs + (cw - 1) * g, t + ch * cs + (ch - 1) * g);
    }

    void ccLayout() {
        float g = Ui.dp(12), cs = Math.min(Ui.dp(78), (H - Ui.dp(72) - 4 * g) / 5f);
        float pw = 4 * cs + 3 * g, ph = 5 * cs + 4 * g, px = W - pw - Ui.dp(18), py = Ui.dp(46);
        ccPanel.set(px, py, px + pw, py + ph);
        mConn = cell(px, py, cs, g, 0, 0, 2, 2); mMedia = cell(px, py, cs, g, 2, 0, 2, 2);
        for (int i = 0; i < 4; i++) {
            float qw = mConn.width() / 2, qh = mConn.height() / 2;
            tiles[i] = new RectF(mConn.left + (i % 2) * qw, mConn.top + (i / 2) * qh, mConn.left + (i % 2 + 1) * qw, mConn.top + (i / 2 + 1) * qh);
        }
        tiles[4] = cell(px, py, cs, g, 0, 2, 1, 1); tiles[5] = cell(px, py, cs, g, 1, 2, 1, 1); tiles[6] = cell(px, py, cs, g, 2, 2, 2, 1);
        sB = cell(px, py, cs, g, 0, 3, 1, 2); sV = cell(px, py, cs, g, 1, 3, 1, 2);
        tiles[7] = cell(px, py, cs, g, 2, 3, 1, 1); tiles[8] = cell(px, py, cs, g, 3, 3, 1, 1);
        tiles[9] = cell(px, py, cs, g, 2, 4, 1, 1); tiles[10] = cell(px, py, cs, g, 3, 4, 1, 1);
    }

    void captureCC() {
        if (W <= 0) return;
        Bitmap b = Bitmap.createBitmap(Math.max(2, W / 4), Math.max(2, H / 4), Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b); cv.scale(b.getWidth() / (float) W, b.getHeight() / (float) H);
        render(cv, SystemClock.uptimeMillis(), false);
        ccSnap = blur(b, 3);
    }

    void ccAnimate(boolean open) {
        ccOpen = open;
        if (open && ccT < 0.01f) captureCC();
        if (ccAnim != null) ccAnim.cancel();
        final float from = ccT, to = open ? 1f : 0f;
        ccAnim = ValueAnimator.ofFloat(0, 1); ccAnim.setDuration(open ? 600 : 340);
        ccAnim.setInterpolator(open ? new Ui.Spring(8f, 7f) : new DecelerateInterpolator(1.6f));
        ccAnim.addUpdateListener(v -> { ccT = Math.max(0f, from + (to - from) * (float) v.getAnimatedValue()); invalidate(); });
        ccAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator a) { cn = true; }
            @Override public void onAnimationEnd(Animator a) { if (!cn) { ccT = to; invalidate(); } } });
        ccAnim.start();
    }

    void setSlider(float y) {
        RectF r = sliderDrag == 0 ? sB : sV;
        float v = Ui.cl(1 - (y - r.top) / r.height());
        if (sliderDrag == 0) brightness = Math.max(0.12f, v); else volume = v;
        invalidate();
    }

    boolean ccTouch(MotionEvent e) {
        float x = e.getX(), y = e.getY(); int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            ccDown = false; sliderDrag = -1;
            if (ccOpen) {
                ccDown = true; downX = x; downY = y; ccLayout();
                if (sB.contains(x, y)) { sliderDrag = 0; setSlider(y); } else if (sV.contains(x, y)) { sliderDrag = 1; setSlider(y); }
                return true;
            }
            if (menuApp == null && x > W * 0.62f && y < Ui.dp(34) && (openAnim == null || !openAnim.isRunning())) { ccPending = true; ccDrag = false; downX = x; downY = y; return true; }
            return false;
        }
        if (ccOpen && ccDown) {
            if (act == MotionEvent.ACTION_MOVE) {
                if (sliderDrag >= 0) setSlider(y); else if (y - downY < -Ui.dp(50)) { ccDown = false; ccAnimate(false); }
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                if (sliderDrag < 0 && act == MotionEvent.ACTION_UP && Math.abs(x - downX) < slop * 2 && Math.abs(y - downY) < slop * 2) ccTap(x, y);
                sliderDrag = -1; ccDown = false;
            }
            return true;
        }
        if (ccPending) {
            if (act == MotionEvent.ACTION_MOVE) {
                float dy = y - downY;
                if (!ccDrag && dy > slop) { ccDrag = true; if (ccAnim != null) ccAnim.cancel(); captureCC(); }
                if (ccDrag) { ccT = Ui.cl(dy / Ui.dp(230)); invalidate(); }
            } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                boolean was = ccDrag; ccPending = false; ccDrag = false;
                if (was) ccAnimate(ccT > 0.3f && act == MotionEvent.ACTION_UP);
            }
            return true;
        }
        return false;
    }

    void ccTap(float x, float y) {
        ccLayout();
        if (!ccPanel.contains(x, y)) { ccAnimate(false); return; }
        for (int i = 0; i < tiles.length; i++) {
            if (tiles[i] != null && tiles[i].contains(x, y)) {
                performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP);
                tileOn[i] = !tileOn[i];
                if (i == 0 && tileOn[0]) { tileOn[1] = false; tileOn[2] = false; tileOn[3] = false; }
                if ((i == 1 || i == 2 || i == 3) && tileOn[i]) tileOn[0] = false;
                invalidate(); return;
            }
        }
    }

    void modStart(Canvas c, RectF r, int idx) {
        float a = Ui.cl(ccT * 1.6f - idx * 0.07f), sc = Ui.lerp(0.9f, 1f, a);
        c.save(); c.scale(sc, sc, r.centerX(), r.centerY());
        c.saveLayerAlpha(r.left - 8, r.top - 8, r.right + 8, r.bottom + 8, (int) (255 * a));
    }
    void modEnd(Canvas c) { c.restore(); c.restore(); }

    void glass(Canvas c, RectF r, float rad) {
        Path p = new Path(); p.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.save(); c.clipPath(p); c.drawBitmap(ccSnap, null, new RectF(0, 0, W, H), bp); fp.setColor(0x6640404A); c.drawRect(r, fp); c.restore();
    }

    boolean drawCC(Canvas c) {
        float t = ccT; boolean busy = false;
        ccLayout();
        bp.setAlpha((int) (255 * Math.min(1f, t * 1.3f))); c.drawBitmap(ccSnap, null, new RectF(0, 0, W, H), bp); bp.setAlpha(255);
        fp.setColor(Color.argb((int) (90 * Math.min(1f, t)), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        c.save();
        c.translate(0, -Ui.dp(26) * (1 - Math.min(1f, t)));
        float ps = Ui.lerp(0.92f, 1f, Math.min(1f, t)); c.scale(ps, ps, ccPanel.right, ccPanel.top);
        float R = Ui.dp(22);
        // connectivity
        modStart(c, mConn, 0); glass(c, mConn, R);
        int[] oc = {0xFFFF9F0A, 0xFF30D158, 0xFF0A84FF, 0xFF0A84FF};
        for (int i = 0; i < 4; i++) {
            RectF q = tiles[i]; float rad = Math.min(q.width(), q.height()) / 2f - Ui.dp(5);
            tileT[i] += ((tileOn[i] ? 1f : 0f) - tileT[i]) * 0.28f; if (Math.abs((tileOn[i] ? 1f : 0f) - tileT[i]) > 0.01f) busy = true;
            fp.setColor(mix(0xFF303036, oc[i], tileT[i])); c.drawCircle(q.centerX(), q.centerY(), rad, fp);
            gl(c, i, q.centerX(), q.centerY(), rad * 1.05f, 0xFFFFFFFF);
        }
        modEnd(c);
        // media
        modStart(c, mMedia, 1); glass(c, mMedia, R);
        gl(c, 16, mMedia.left + Ui.dp(22), mMedia.top + Ui.dp(22), Ui.dp(18), 0xCCFFFFFF);
        gl(c, 6, mMedia.right - Ui.dp(22), mMedia.top + Ui.dp(22), Ui.dp(18), 0xCCFFFFFF);
        txt(c, "Not Playing", mMedia.centerX(), mMedia.centerY() - Ui.dp(2), 0xFFFFFFFF, 13.5f, Ui.MED, Paint.Align.CENTER);
        float my = mMedia.bottom - Ui.dp(26), mw = mMedia.width() / 4;
        gl(c, 13, mMedia.centerX() - mw, my, Ui.dp(20), 0xAAFFFFFF); gl(c, 14, mMedia.centerX(), my, Ui.dp(24), 0xFFFFFFFF); gl(c, 15, mMedia.centerX() + mw, my, Ui.dp(20), 0xAAFFFFFF);
        modEnd(c);
        // small tiles
        int[] gid = {4, 5, 6, 7, 8, 9, 10};
        int[] onc = {0xFFFF3B30, 0xFF5E5CE6, 0xFF0A84FF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFFFFFF};
        for (int k = 0; k < 7; k++) {
            int i = 4 + k; RectF r = tiles[i];
            modStart(c, r, 2 + k); glass(c, r, R);
            tileT[i] += ((tileOn[i] ? 1f : 0f) - tileT[i]) * 0.28f; if (Math.abs((tileOn[i] ? 1f : 0f) - tileT[i]) > 0.01f) busy = true;
            if (tileT[i] > 0.01f) { fp.setColor((onc[k] & 0xFFFFFF) | ((int) (255 * Ui.cl(tileT[i])) << 24)); c.drawRoundRect(r, R, R, fp); }
            boolean light = onc[k] == 0xFFFFFFFF && tileT[i] > 0.5f;
            if (i == 6) {
                gl(c, 6, r.left + Ui.dp(30), r.centerY(), Ui.dp(24), 0xFFFFFFFF);
                txt(c, "Screen", r.left + Ui.dp(52), r.centerY() - Ui.dp(2), 0xFFFFFFFF, 12.5f, Ui.MED, Paint.Align.LEFT);
                txt(c, "Mirroring", r.left + Ui.dp(52), r.centerY() + Ui.dp(13), 0xFFFFFFFF, 12.5f, Ui.MED, Paint.Align.LEFT);
            } else gl(c, gid[k], r.centerX(), r.centerY(), Math.min(r.width(), r.height()) * 0.42f, light ? 0xFF1C1C1E : 0xFFFFFFFF);
            modEnd(c);
        }
        // sliders
        for (int k = 0; k < 2; k++) {
            RectF r = k == 0 ? sB : sV; float lv = k == 0 ? brightness : volume;
            modStart(c, r, 9 + k); glass(c, r, R);
            Path p = new Path(); p.addRoundRect(r, R, R, Path.Direction.CW);
            c.save(); c.clipPath(p);
            fp.setColor(0xF2FFFFFF); c.drawRect(r.left, r.bottom - r.height() * lv, r.right, r.bottom, fp);
            c.restore();
            gl(c, k == 0 ? 11 : 12, r.centerX(), r.bottom - Ui.dp(26), Ui.dp(24), lv > 0.16f ? 0xFF3A3A3C : 0xFFFFFFFF);
            modEnd(c);
        }
        c.restore();
        return busy;
    }

    void fpoly(Canvas c, float... q) {
        Path p = new Path(); p.moveTo(q[0], q[1]); for (int i = 2; i < q.length; i += 2) p.lineTo(q[i], q[i + 1]); p.close();
        gp.setStyle(Paint.Style.FILL); c.drawPath(p, gp);
    }

    /** Control Center glyphs on a 24-unit grid centred at (cx, cy) with box size s. */
    void gl(Canvas c, int id, float cx, float cy, float s, int col) {
        c.save(); c.translate(cx, cy); c.scale(s / 24f, s / 24f); c.translate(-12, -12);
        gp.setColor(col); gp.setStrokeCap(Paint.Cap.ROUND); gp.setStrokeJoin(Paint.Join.ROUND); gp.setStrokeWidth(2f); gp.setShader(null);
        Path p = new Path();
        switch (id) {
            case 0: fpoly(c, 12, 2, 14, 9, 22, 14, 22, 16, 14, 13.5f, 13, 19, 16, 21, 16, 22, 12, 21, 8, 22, 8, 21, 11, 19, 10, 13.5f, 2, 16, 2, 14, 10, 9); break;
            case 1: gp.setStyle(Paint.Style.FILL); for (int i = 0; i < 4; i++) c.drawRoundRect(3 + 5.2f * i, 20 - (4 + 4 * i), 6.4f + 5.2f * i, 20, 1, 1, gp); break;
            case 2: gp.setStyle(Paint.Style.STROKE); gp.setStrokeWidth(2.4f);
                for (float r : new float[]{5f, 9.5f, 14f}) c.drawArc(12 - r, 19.5f - r, 12 + r, 19.5f + r, -135, 90, false, gp);
                gp.setStyle(Paint.Style.FILL); c.drawCircle(12, 19.2f, 1.8f, gp); break;
            case 3: p.moveTo(6.5f, 8); p.lineTo(17, 16.5f); p.lineTo(12, 21); p.lineTo(12, 3); p.lineTo(17, 7.5f); p.lineTo(6.5f, 16);
                gp.setStyle(Paint.Style.STROKE); c.drawPath(p, gp); break;
            case 4: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(7, 6, 17, 18, 2.2f, 2.2f, gp); c.drawArc(2.5f, 2.5f, 21.5f, 21.5f, 150, 70, false, gp); c.drawArc(2.5f, 2.5f, 21.5f, 21.5f, -30, 70, false, gp); break;
            case 5: { Path a = new Path(), b = new Path(); a.addCircle(12, 12, 9, Path.Direction.CW); b.addCircle(17.5f, 7.5f, 8, Path.Direction.CW); a.op(b, Path.Op.DIFFERENCE); gp.setStyle(Paint.Style.FILL); c.drawPath(a, gp); break; }
            case 6: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(2.5f, 5, 21.5f, 17, 2, 2, gp); c.drawLine(8, 21, 16, 21, gp); break;
            case 7: gp.setStyle(Paint.Style.FILL); c.drawRoundRect(8, 10, 16, 22, 2, 2, gp); fpoly(c, 7, 2.5f, 17, 2.5f, 16, 9, 8, 9); break;
            case 8: gp.setStyle(Paint.Style.STROKE); c.drawCircle(12, 13, 8, gp); c.drawLine(12, 13, 12, 8.5f, gp); c.drawLine(9.5f, 2.5f, 14.5f, 2.5f, gp); break;
            case 9: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(5, 3, 19, 21, 2.5f, 2.5f, gp); gp.setStyle(Paint.Style.FILL); c.drawRoundRect(7.5f, 5.5f, 16.5f, 9.5f, 1, 1, gp);
                for (int r = 0; r < 2; r++) for (int q = 0; q < 3; q++) c.drawCircle(9 + 3 * q, 13.5f + 3.6f * r, 1.1f, gp); break;
            case 10: gp.setStyle(Paint.Style.STROKE); c.drawRoundRect(2.5f, 7, 21.5f, 20, 3, 3, gp); c.drawCircle(12, 13.5f, 4, gp); c.drawLine(8.5f, 5, 15.5f, 5, gp); break;
            case 11: gp.setStyle(Paint.Style.FILL); c.drawCircle(12, 12, 4.2f, gp); gp.setStyle(Paint.Style.STROKE);
                for (int i = 0; i < 8; i++) { c.save(); c.rotate(i * 45, 12, 12); c.drawLine(12, 2.5f, 12, 5, gp); c.restore(); } break;
            case 12: fpoly(c, 3, 9, 7, 9, 12, 5, 12, 19, 7, 15, 3, 15); gp.setStyle(Paint.Style.STROKE);
                c.drawArc(7, 7, 17, 17, -50, 100, false, gp); c.drawArc(3, 3, 21, 21, -50, 100, false, gp); break;
            case 13: fpoly(c, 11, 5, 11, 19, 2, 12); fpoly(c, 21, 5, 21, 19, 12, 12); break;
            case 14: fpoly(c, 6, 3, 6, 21, 21, 12); break;
            case 15: fpoly(c, 13, 5, 13, 19, 22, 12); fpoly(c, 3, 5, 3, 19, 12, 12); break;
            case 16: gp.setStyle(Paint.Style.FILL); c.drawCircle(8, 18, 3.6f, gp); fpoly(c, 11.4f, 5, 19, 7.5f, 19, 11, 11.4f, 8.5f); gp.setStyle(Paint.Style.STROKE); c.drawLine(11.4f, 18, 11.4f, 5, gp); break;
        }
        c.restore();
    }

    // ---------------------------------------------------------------- touch
    final Runnable lp = new Runnable() { public void run() {
        if (pressed != null && !moved && openApp == null && menuApp == null) { lpFired = true; performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); showMenu(pressed); }
    } };

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        if (ccTouch(e)) return true;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x; downY = y; moved = false; lpFired = false; closing = false;
                if (vt != null) vt.recycle(); vt = VelocityTracker.obtain(); vt.addMovement(e);
                if (openAnim != null && openAnim.isRunning()) { return true; }
                if (openApp != null) { closing = y > H * 0.78f; return true; }
                if (menuApp != null) return true;
                if (pageAnim != null) pageAnim.cancel();
                startPage = pageF; pressed = hit(x, y);
                if (pressed != null && !jiggle) postDelayed(lp, 450);
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE: {
                vt.addMovement(e);
                float dx = x - downX, dy = y - downY;
                if (openApp != null) { if (closing && dy < 0) { openT = Math.max(0f, 1 + dy / (H * 0.65f)); dragDx = dx; invalidate(); } return true; }
                if (menuApp != null) return true;
                if (!moved && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) { moved = true; removeCallbacks(lp); pressed = null; }
                if (moved) {
                    float v = startPage - dx / W, mx = pages - 1;
                    if (v < 0) v *= 0.22f; else if (v > mx) v = mx + (v - mx) * 0.22f;   // edge resistance only
                    pageF = v; invalidate();
                }
                else if (Math.abs(dy) > slop) { removeCallbacks(lp); pressed = null; }
                return true;
            }
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: {
                vt.addMovement(e); vt.computeCurrentVelocity(1000);
                removeCallbacks(lp);
                boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                float dx = x - downX, dy = y - downY;
                if (openAnim != null && openAnim.isRunning()) return true;
                if (openApp != null) {
                    if (up && !closing && openApp.id.equals("gfx") && openT > 0.9f && Math.abs(dx) < slop * 2 && Math.abs(dy) < slop * 2) {
                        RectF hb = new RectF(gfxToggle); hb.inset(-Ui.dp(12), -Ui.dp(12));
                        if (hb.contains(x, y)) { setGfx(!Ui.gfx); return true; }
                    }
                    if (closing && up && (dy < -H * 0.1f || vt.getYVelocity() < -900 || (Math.abs(dy) < slop && y > H - Ui.dp(24)))) animateOpen(false);
                    else if (openT < 1f) animateOpen(true);
                    return true;
                }
                if (menuApp != null) { if (up) menuTap(x, y); return true; }
                App p = pressed; pressed = null;
                if (moved) {
                    int target = Math.round(startPage);
                    if (Math.abs(dx) > W * 0.12f || Math.abs(vt.getXVelocity()) > 900) target += dx < 0 ? 1 : -1;
                    snap(Math.max(0, Math.min(pages - 1, target)));
                } else if (up && !lpFired) {
                    if (jiggle) {
                        if (doneBtn.contains(x, y)) jiggle = false;
                        else if (p != null && !p.dock) { RectF r = screenRect(p); if (Math.hypot(x - (r.left + Ui.dp(2)), y - (r.top + Ui.dp(2))) < Ui.dp(20)) { p.removed = true; layoutApps(); } }
                    } else if (p != null) { ir = screenRect(p); openApp = p; animateOpen(true); }
                }
                if (pageF != Math.round(pageF) && (pageAnim == null || !pageAnim.isRunning())) snap(Math.round(pageF));
                invalidate(); return true;
            }
        }
        return true;
    }

    void menuTap(float x, float y) {
        if (menuRect.contains(x, y)) {
            float rh = Ui.dp(ROW), rel = y - menuRect.top; int i;
            if (rel < 3 * rh) i = (int) (rel / rh); else if (rel < 3 * rh + Ui.dp(SEP)) i = -1; else i = 3 + (int) ((rel - 3 * rh - Ui.dp(SEP)) / rh);
            if (i < 0) return;
            App a = menuApp;
            if (i == 0) { a.removed = true; layoutApps(); menuAnim(menuT, 0, 160); }
            else if (i == 1) menuAnim(menuT, 0, 160);
            else if (i == 2) { jiggle = true; menuAnim(menuT, 0, 160); }
            else { ir = screenRect(a); openApp = a; menuApp = null; menuT = 0; animateOpen(true); }
        } else menuAnim(menuT, 0, 160);
    }

    void snap(int target) {
        if (pageAnim != null) pageAnim.cancel();
        pageAnim = ValueAnimator.ofFloat(pageF, target); pageAnim.setDuration(460); pageAnim.setInterpolator(new Ui.Smooth());
        pageAnim.addUpdateListener(v -> { pageF = (float) v.getAnimatedValue(); invalidate(); });
        pageAnim.start();
    }

    void animateOpen(boolean open) {
        if (openAnim != null) openAnim.cancel();
        if (open && openT < 0.01f) captureSnap();
        final float from = openT, to = open ? 1f : 0f;
        openAnim = ValueAnimator.ofFloat(0, 1); openAnim.setDuration(open ? 820 : 700); openAnim.setInterpolator(new Ui.Smooth());
        final float dx0 = dragDx;
        openAnim.addUpdateListener(v -> { float f = (float) v.getAnimatedValue(); openT = Math.max(0f, from + (to - from) * f); dragDx = dx0 * (1 - Math.min(1f, f)); invalidate(); });
        openAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator a) { cn = true; }
            @Override public void onAnimationEnd(Animator a) { if (cn) return; openT = to; dragDx = 0; if (!open) { openApp = null; } invalidate(); } });
        openAnim.start();
    }

    boolean handleBack() {
        if (ccOpen) { ccAnimate(false); return true; }
        if (menuApp != null) { menuAnim(menuT, 0, 160); return true; }
        if (openApp != null && (openAnim == null || !openAnim.isRunning())) { animateOpen(false); return true; }
        if (jiggle) { jiggle = false; invalidate(); return true; }
        return false;
    }
}
