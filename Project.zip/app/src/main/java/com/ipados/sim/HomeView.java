package com.ipados.sim;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.*;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import java.util.ArrayList;

public class HomeView extends View {
    static final int COLS = 7, ROWS = 4, LABEL_DP = 18;

    static class App {
        String id, name; int page; boolean removed, dock; float cx, top, sz, press = 1f, phase;
    }

    final ArrayList<App> apps = new ArrayList<>(), dock = new ArrayList<>();
    final Paint bp = new Paint(Paint.FILTER_BITMAP_FLAG), fp = Ui.p(0);
    Bitmap wp;
    int W, H, pages = 2, slop;
    float iconSz, dockSz, cellW, cellH, gridTop, dockTop, dockBottom, vPad, hPad, label;
    final RectF wWeather = new RectF(), wCal = new RectF(), wBat = new RectF(), dockRect = new RectF(), doneBtn = new RectF();

    float pageF = 0, startPage, downX, downY, openT = 0;
    boolean moved, jiggle, lpFired, closing;
    App pressed, openApp;
    RectF ir = new RectF();
    ValueAnimator pageAnim, openAnim, menuAnim;
    VelocityTracker vt;
    long lastSec = -1;

    // context menu
    App menuApp; String[] menuItems; final RectF menuRect = new RectF(); float menuT = 0;
    static final float ROW = 46, SEP = 6;

    void add(String id, String name, int page, boolean dk) {
        App a = new App(); a.id = id; a.name = name; a.page = page; a.dock = dk; a.phase = (float) (Math.random() * 6.28);
        (dk ? dock : apps).add(a);
    }

    public HomeView(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        add("messages", "Messages", 0, true); add("facetime", "FaceTime", 0, true); add("mail", "Mail", 0, true);
        add("safari", "Safari", 0, true); add("photos", "Photos", 0, true); add("maps", "Maps", 0, true);
        add("camera", "Camera", 0, true); add("settings", "Settings", 0, true); add("files", "Files", 0, true);
        add("appstore", "App Store", 0, true);
        add("calendar", "Calendar", 0, false); add("clock", "Clock", 0, false); add("notes", "Notes", 0, false);
        add("reminders", "Reminders", 0, false); add("weather", "Weather", 0, false); add("stocks", "Stocks", 0, false);
        add("music", "Music", 1, false); add("books", "Books", 1, false);
    }

    @Override protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w; H = h; wp = Ui.wallpaper(w, h);
        label = Ui.dp(LABEL_DP);
        gridTop = Ui.dp(44);
        dockSz = Math.min(Ui.dp(64), W / (dock.size() + 4f));
        float dockH = dockSz + Ui.dp(20);
        dockBottom = H - Ui.dp(10); dockTop = dockBottom - dockH;
        float gridBottom = dockTop - Ui.dp(26);
        cellW = W / (float) COLS; cellH = (gridBottom - gridTop) / ROWS;
        iconSz = Math.min(cellW * 0.58f, (cellH - label) * 0.82f);
        vPad = (cellH - iconSz - label) / 2; hPad = (cellW - iconSz) / 2;
        wRect(wWeather, 0, 0, 3, 2); wRect(wCal, 3, 0, 2, 2); wRect(wBat, 5, 0, 2, 1);
        float gap = dockSz * 0.28f, total = dock.size() * dockSz + (dock.size() - 1) * gap, x0 = (W - total) / 2;
        for (int i = 0; i < dock.size(); i++) { App a = dock.get(i); a.sz = dockSz; a.cx = x0 + i * (dockSz + gap) + dockSz / 2; a.top = dockTop + Ui.dp(10); }
        dockRect.set(x0 - Ui.dp(16), dockTop, x0 + total + Ui.dp(16), dockBottom);
        doneBtn.set(W - Ui.dp(92), Ui.dp(30), W - Ui.dp(16), Ui.dp(62));
        layoutApps();
    }

    void wRect(RectF r, int col, int row, int cw, int ch) {
        r.set(col * cellW + hPad, gridTop + row * cellH + vPad, (col + cw) * cellW - hPad, gridTop + (row + ch) * cellH - vPad - label);
    }

    void layoutApps() {
        boolean[][] occ = new boolean[ROWS][COLS];
        for (int r = 0; r < 2; r++) for (int c = 0; c < 5; c++) occ[r][c] = true;
        occ[0][5] = occ[0][6] = true;
        for (int pg = 0; pg < pages; pg++) {
            int r = 0, c = 0;
            for (App a : apps) {
                if (a.page != pg || a.removed) continue;
                while (pg == 0 && r < ROWS && occ[r][c]) { c++; if (c == COLS) { c = 0; r++; } }
                if (r >= ROWS) break;
                a.sz = iconSz; a.cx = c * cellW + cellW / 2; a.top = gridTop + r * cellH + vPad;
                c++; if (c == COLS) { c = 0; r++; }
            }
        }
    }

    RectF screenRect(App a) {
        float sh = a.dock ? 0 : (a.page - pageF) * W;
        return new RectF(a.cx - a.sz / 2 + sh, a.top, a.cx + a.sz / 2 + sh, a.top + a.sz);
    }

    App hit(float x, float y) {
        for (App a : dock) { RectF r = screenRect(a); r.inset(-Ui.dp(6), -Ui.dp(6)); if (r.contains(x, y)) return a; }
        int pg = Math.round(pageF);
        for (App a : apps) {
            if (a.removed || a.page != pg) continue;
            RectF r = screenRect(a); r.inset(-Ui.dp(6), -Ui.dp(4)); r.bottom += label;
            if (r.contains(x, y)) return a;
        }
        return null;
    }

    // ---------------------------------------------------------------- drawing
    @Override protected void onDraw(Canvas c) {
        if (wp == null) return;
        long now = SystemClock.uptimeMillis();
        if (now / 1000 != lastSec) {
            lastSec = now / 1000; Icons.calDay = Ui.fmt("EEE").toUpperCase(); Icons.calNum = Ui.fmt("d");
        }
        boolean anim = jiggle || (pageAnim != null && pageAnim.isRunning());
        float tc = Math.max(0, openT);
        c.save();
        float s = 1 - 0.05f * Math.min(1, tc);
        c.scale(s, s, W / 2f, H / 2f);
        c.drawBitmap(wp, null, new RectF(0, 0, W, H), bp);
        c.drawColor(0x1A000000);
        Ui.statusBar(c, W, true, 0xFFFFFFFF);
        int sv = c.save();
        for (int pg = 0; pg < pages; pg++) {
            float x = (pg - pageF) * W;
            if (Math.abs(x) >= W) continue;
            c.save(); c.translate(x, 0);
            if (pg == 0) { drawWeather(c, wWeather); drawCalendar(c, wCal); drawBattery(c, wBat); }
            for (App a : apps) if (a.page == pg && !a.removed && a != menuApp) { if (drawApp(c, a, now, true)) anim = true; }
            c.restore();
        }
        // page dots
        for (int i = 0; i < pages; i++) {
            Paint d = Ui.p(0xFFFFFFFF); d.setAlpha(Math.abs(i - pageF) < 0.5f ? 255 : 110);
            c.drawCircle(W / 2f + (i - (pages - 1) / 2f) * Ui.dp(14), dockTop - Ui.dp(12), Ui.dp(3.2f), d);
        }
        // dock
        fp.setColor(0x4DFFFFFF); c.drawRoundRect(dockRect, Ui.dp(28), Ui.dp(28), fp);
        fp.setStyle(Paint.Style.STROKE); fp.setStrokeWidth(Ui.dp(0.6f)); fp.setColor(0x33FFFFFF); c.drawRoundRect(dockRect, Ui.dp(28), Ui.dp(28), fp); fp.setStyle(Paint.Style.FILL);
        for (App a : dock) if (a != menuApp) { if (drawApp(c, a, now, false)) anim = true; }
        if (jiggle) {
            fp.setColor(0x66000000); c.drawRoundRect(doneBtn, Ui.dp(16), Ui.dp(16), fp);
            c.drawText("Done", doneBtn.centerX(), doneBtn.centerY() + Ui.dp(5), Ui.tx(0xFFFFFFFF, 15, Ui.MED, Paint.Align.CENTER));
        }
        c.restoreToCount(sv);
        // menu
        if (menuApp != null) { drawMenu(c); }
        c.restore();
        if (tc > 0.001f) drawWindow(c);
        if (anim || menuApp != null) postInvalidateOnAnimation();
    }

    boolean drawApp(Canvas c, App a, long now, boolean labels) {
        float target = (a == pressed && !moved && openApp == null && menuApp == null) ? 0.9f : 1f;
        boolean busy = false;
        if (Math.abs(a.press - target) > 0.002f) { a.press += (target - a.press) * 0.35f; busy = true; }
        float rot = jiggle ? (float) Math.sin(now / 62.0 + a.phase) * 1.7f : 0;
        float cx = a.cx, cy = a.top + a.sz / 2;
        c.save(); c.scale(a.press, a.press, cx, cy); if (rot != 0) c.rotate(rot, cx, cy);
        Icons.draw(c, a.id, cx - a.sz / 2, a.top, a.sz);
        if (jiggle) {
            fp.setColor(0xFFB8B8BE); c.drawCircle(cx - a.sz / 2 + Ui.dp(2), a.top + Ui.dp(2), Ui.dp(9), fp);
            fp.setColor(0xFF2C2C2E); c.drawRoundRect(cx - a.sz / 2 - Ui.dp(2.5f), a.top + Ui.dp(0.9f), cx - a.sz / 2 + Ui.dp(6.5f), a.top + Ui.dp(3.1f), Ui.dp(1), Ui.dp(1), fp);
        }
        c.restore();
        if (labels) c.drawText(a.name, cx, a.top + a.sz + Ui.dp(14), Ui.tx(0xFFFFFFFF, 11.5f, Ui.REG, Paint.Align.CENTER));
        return busy;
    }

    void card(Canvas c, RectF r, int col) { fp.setStyle(Paint.Style.FILL); fp.setColor(col); c.drawRoundRect(r, Ui.dp(22), Ui.dp(22), fp); }
    void txt(Canvas c, String s, float x, float y, int col, float sz, Typeface f, Paint.Align al) { c.drawText(s, x, y, Ui.tx(col, sz, f, al)); }

    void drawWeather(Canvas c, RectF r) {
        card(c, r, 0xD91C1C1E);
        float u = Math.max(0.5f, Math.min(r.height() / Ui.dp(160), r.width() / Ui.dp(300))), x = r.left + Ui.dp(16) * u, y = r.top;
        txt(c, "Cupertino", x, y + Ui.dp(26) * u, 0xFFFFFFFF, 15 * u, Ui.BOLD, Paint.Align.LEFT);
        txt(c, "72\u00B0", x, y + Ui.dp(72) * u, 0xFFFFFFFF, 44 * u, Ui.LIGHT, Paint.Align.LEFT);
        fp.setColor(0xFFFFCC00); c.drawCircle(r.right - Ui.dp(38) * u, y + Ui.dp(34) * u, Ui.dp(11) * u, fp);
        txt(c, "Sunny", r.right - Ui.dp(16) * u, y + Ui.dp(64) * u, 0xFFFFFFFF, 13 * u, Ui.MED, Paint.Align.RIGHT);
        txt(c, "H:78\u00B0  L:61\u00B0", r.right - Ui.dp(16) * u, y + Ui.dp(82) * u, 0xCCFFFFFF, 12 * u, Ui.REG, Paint.Align.RIGHT);
        String[] t = {"Now", "10 AM", "11 AM", "12 PM", "1 PM"}; int[] d = {72, 74, 76, 77, 77};
        float cw = (r.width() - Ui.dp(32) * u) / 5;
        for (int i = 0; i < 5; i++) {
            float cx = x + cw * i + cw / 2;
            txt(c, t[i], cx, y + Ui.dp(116) * u, 0xCCFFFFFF, 11 * u, Ui.MED, Paint.Align.CENTER);
            fp.setColor(0xFFFFCC00); c.drawCircle(cx, y + Ui.dp(130) * u, Ui.dp(5.5f) * u, fp);
            txt(c, d[i] + "\u00B0", cx, y + Ui.dp(150) * u, 0xFFFFFFFF, 12.5f * u, Ui.MED, Paint.Align.CENTER);
        }
    }

    void drawCalendar(Canvas c, RectF r) {
        card(c, r, 0xD91C1C1E);
        float u = Math.max(0.5f, Math.min(r.height() / Ui.dp(160), r.width() / Ui.dp(160))), x = r.left + Ui.dp(14) * u;
        txt(c, Ui.fmt("EEEE").toUpperCase(), x, r.top + Ui.dp(26) * u, 0xFFFF453A, 12 * u, Ui.BOLD, Paint.Align.LEFT);
        txt(c, Ui.fmt("d"), x, r.top + Ui.dp(70) * u, 0xFFFFFFFF, 44 * u, Ui.LIGHT, Paint.Align.LEFT);
        String[] ev = {"Design review", "Lunch with Marcel", "Timesheet deadline"}; String[] tm = {"10:30 AM", "12:00 PM", "5:00 PM"};
        int[] col = {0xFF0A84FF, 0xFF30D158, 0xFFFF9F0A};
        for (int i = 0; i < 3; i++) {
            float y = r.top + Ui.dp(92) * u + i * Ui.dp(22) * u;
            fp.setColor(col[i]); c.drawRoundRect(x, y - Ui.dp(11) * u, x + Ui.dp(3) * u, y + Ui.dp(7) * u, 2, 2, fp);
            txt(c, ev[i], x + Ui.dp(9) * u, y - Ui.dp(1) * u, 0xFFFFFFFF, 11 * u, Ui.MED, Paint.Align.LEFT);
            txt(c, tm[i], x + Ui.dp(9) * u, y + Ui.dp(8) * u, 0x99FFFFFF, 9 * u, Ui.REG, Paint.Align.LEFT);
        }
    }

    void drawBattery(Canvas c, RectF r) {
        card(c, r, 0xD91C1C1E);
        float rad = r.height() * 0.3f;
        for (int i = 0; i < 2; i++) {
            float cx = r.left + r.width() * (0.28f + 0.44f * i), cy = r.centerY();
            Ui.ring(c, cx, cy, rad, 1f, i == 0 ? 0xFF30D158 : 0xFF30D158, 3.4f);
            Icons.fill(0xFFFFFFFF);
            c.drawRoundRect(cx - rad * 0.3f, cy - rad * 0.45f, cx + rad * 0.3f, cy + rad * 0.45f, 3, 3, Icons.P);
        }
    }

    // ---------------------------------------------------------------- context menu
    String[] extras(String id) {
        switch (id) {
            case "notes": return new String[]{"New Note", "New Checklist"};
            case "camera": return new String[]{"Take Selfie", "Record Video"};
            case "messages": case "mail": return new String[]{"New Message", "Search"};
            case "reminders": return new String[]{"New Reminder", "Add List"};
            case "safari": return new String[]{"New Tab", "New Private Tab"};
            default: return new String[]{"Open", "Search"};
        }
    }

    void showMenu(App a) {
        menuApp = a; String[] e = extras(a.id);
        menuItems = new String[]{"Remove App", "Share App", "Edit Home Screen", e[0], e[1]};
        float w = Ui.dp(250), h = ROW * Ui.d * 5 + SEP * Ui.d;
        RectF r = screenRect(a);
        float l = Math.max(Ui.dp(12), Math.min(r.left, W - w - Ui.dp(12)));
        float t = r.bottom + label + Ui.dp(6);
        if (t + h > H - Ui.dp(12)) t = Math.max(Ui.dp(12), r.top - h - Ui.dp(10));
        menuRect.set(l, t, l + w, t + h);
        menuAnim(0, 1, 280);
    }

    void menuAnim(float from, float to, int ms) {
        if (menuAnim != null) menuAnim.cancel();
        menuAnim = ValueAnimator.ofFloat(from, to); menuAnim.setDuration(ms); menuAnim.setInterpolator(new DecelerateInterpolator(1.6f));
        menuAnim.addUpdateListener(v -> { menuT = (float) v.getAnimatedValue(); invalidate(); });
        if (to == 0) menuAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator an) { cn = true; }
            @Override public void onAnimationEnd(Animator an) { if (!cn) { menuApp = null; } } });
        menuAnim.start();
    }

    void drawMenu(Canvas c) {
        fp.setColor(Color.argb((int) (90 * menuT), 0, 0, 0)); c.drawRect(0, 0, W, H, fp);
        App a = menuApp; RectF r = screenRect(a);
        c.save(); float s = 1 + 0.08f * menuT; c.scale(s, s, r.centerX(), r.centerY()); Icons.draw(c, a.id, r.left, r.top, r.width()); c.restore();
        c.save();
        float sc = Ui.lerp(0.5f, 1f, menuT);
        c.scale(sc, sc, r.centerX() < W / 2f ? menuRect.left : menuRect.right, menuRect.top < r.top ? menuRect.bottom : menuRect.top);
        c.saveLayerAlpha(menuRect.left - 4, menuRect.top - 4, menuRect.right + 4, menuRect.bottom + 4, (int) (255 * Math.min(1, menuT * 1.4f)));
        fp.setColor(0xF0F0F0F5); c.drawRoundRect(menuRect, Ui.dp(16), Ui.dp(16), fp);
        float rh = Ui.dp(ROW), y = menuRect.top;
        for (int i = 0; i < 5; i++) {
            if (i == 3) { fp.setColor(0xFFD4D4DA); c.drawRect(menuRect.left, y, menuRect.right, y + Ui.dp(SEP), fp); y += Ui.dp(SEP); }
            int col = i == 0 ? 0xFFFF3B30 : 0xFF1C1C1E;
            txt(c, menuItems[i], menuRect.left + Ui.dp(16), y + rh / 2 + Ui.dp(5.5f), col, 16.5f, Ui.REG, Paint.Align.LEFT);
            glyph(c, i, menuRect.right - Ui.dp(26), y + rh / 2, col);
            if (i != 2 && i != 4) { fp.setColor(0x1F000000); c.drawRect(menuRect.left, y + rh - 1, menuRect.right, y + rh, fp); }
            y += rh;
        }
        c.restore(); c.restore();
    }

    void glyph(Canvas c, int i, float cx, float cy, int col) {
        Paint s = Ui.p(col); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(Ui.dp(1.5f)); s.setStrokeCap(Paint.Cap.ROUND);
        float u = Ui.dp(1);
        if (i == 0) { c.drawCircle(cx, cy, 8 * u, s); c.drawLine(cx - 4 * u, cy, cx + 4 * u, cy, s); }
        else if (i == 1) { c.drawRoundRect(cx - 6 * u, cy - 3 * u, cx + 6 * u, cy + 8 * u, 2 * u, 2 * u, s); c.drawLine(cx, cy - 9 * u, cx, cy + 3 * u, s); c.drawLine(cx, cy - 9 * u, cx - 3 * u, cy - 6 * u, s); c.drawLine(cx, cy - 9 * u, cx + 3 * u, cy - 6 * u, s); }
        else if (i == 2) { c.drawRoundRect(cx - 5 * u, cy - 8 * u, cx + 5 * u, cy + 8 * u, 2 * u, 2 * u, s); c.drawLine(cx - 2 * u, cy + 5 * u, cx + 2 * u, cy + 5 * u, s); }
        else { c.drawLine(cx - 6 * u, cy, cx + 6 * u, cy, s); c.drawLine(cx, cy - 6 * u, cx, cy + 6 * u, s); }
    }

    // ---------------------------------------------------------------- app window
    void drawWindow(Canvas c) {
        float t = openT, tc = Math.min(1, Math.max(0, t));
        float l = Ui.lerp(ir.left, 0, t), tp = Ui.lerp(ir.top, 0, t), r = Ui.lerp(ir.right, W, t), b = Ui.lerp(ir.bottom, H, t);
        float rad = Ui.lerp(ir.width() * 0.225f, Ui.dp(24), tc);
        Path clip = new Path(); clip.addRoundRect(l, tp, r, b, rad, rad, Path.Direction.CW);
        c.save(); c.clipPath(clip);
        float ia = 1 - Ui.cl((tc - 0.1f) / 0.4f);
        float sa = Ui.cl((tc - 0.3f) / 0.5f);
        fp.setColor(0xFF000000); c.drawRect(l, tp, r, b, fp);
        if (sa > 0) { c.saveLayerAlpha(l, tp, r, b, (int) (255 * sa)); drawSkin(c, openApp); c.restore(); }
        if (ia > 0) {
            float cover = Math.max(r - l, b - tp);
            c.saveLayerAlpha(l, tp, r, b, (int) (255 * ia));
            c.translate((l + r) / 2 - cover / 2, (tp + b) / 2 - cover / 2);
            c.save(); c.clipRect(-1e5f, -1e5f, 1e5f, 1e5f); Icons.draw(c, openApp.id, 0, 0, cover); c.restore();
            c.restore();
        }
        c.restore();
    }

    boolean dark(App a) { return a.id.equals("clock") || a.id.equals("stocks") || a.id.equals("camera"); }

    void drawSkin(Canvas c, App a) {
        if (a.id.equals("settings")) skinSettings(c);
        else {
            boolean dk = dark(a);
            c.drawColor(dk ? 0xFF000000 : 0xFFF2F2F7);
            txt(c, a.name, Ui.dp(32), Ui.dp(92), dk ? 0xFFFFFFFF : 0xFF000000, 34, Ui.BOLD, Paint.Align.LEFT);
            float s = Math.min(Ui.dp(110), H * 0.3f);
            Icons.draw(c, a.id, W / 2f - s / 2, H * 0.36f - s / 2 + Ui.dp(10), s);
            txt(c, "Swipe up from the bottom edge to go home", W / 2f, H * 0.36f + s / 2 + Ui.dp(52), dk ? 0xFF8E8E93 : 0xFF6C6C70, 16, Ui.REG, Paint.Align.CENTER);
        }
        Ui.statusBar(c, W, true, dark(a) || a.id.equals("settings") ? (dark(a) ? 0xFFFFFFFF : 0xFF000000) : 0xFF000000);
        fp.setColor(dark(a) ? 0xB3FFFFFF : 0x99000000); c.drawRoundRect(W / 2f - Ui.dp(70), H - Ui.dp(11), W / 2f + Ui.dp(70), H - Ui.dp(6), Ui.dp(3), Ui.dp(3), fp);
    }

    void toggle(Canvas c, float cx, float cy, boolean on) {
        float w = Ui.dp(48), h = Ui.dp(28);
        fp.setColor(on ? 0xFF34C759 : 0xFFE5E5EA); c.drawRoundRect(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, h / 2, h / 2, fp);
        fp.setColor(0xFFFFFFFF); c.drawCircle(on ? cx + w / 2 - h / 2 : cx - w / 2 + h / 2, cy, h / 2 - Ui.dp(2), fp);
    }

    void skinSettings(Canvas c) {
        c.drawColor(0xFFF2F2F7);
        float sw = Math.max(W * 0.3f, Ui.dp(240)), x = Ui.dp(14);
        txt(c, "Settings", Ui.dp(24), Ui.dp(84), 0xFF000000, 30, Ui.BOLD, Paint.Align.LEFT);
        fp.setColor(0xFFE3E3E8); c.drawRoundRect(x, Ui.dp(100), sw - Ui.dp(8), Ui.dp(136), Ui.dp(10), Ui.dp(10), fp);
        txt(c, "Search", x + Ui.dp(34), Ui.dp(124), 0xFF8E8E93, 15, Ui.REG, Paint.Align.LEFT);
        String[] g = {"Camera", "Control Center", "Display & Brightness", "Home Screen & App Library", "Multitasking & Gestures", "Search", "Siri", "Wallpaper", "Notifications", "Sounds", "Focus", "Screen Time"};
        int[] col = {0xFF8E8E93, 0xFF636366, 0xFF0A84FF, 0xFF5E5CE6, 0xFF0A84FF, 0xFF8E8E93, 0xFF1C1C1E, 0xFF32ADE6, 0xFFFF3B30, 0xFFFF2D55, 0xFF5E5CE6, 0xFF5E5CE6};
        float rh = Ui.dp(40), y = Ui.dp(152);
        for (int i = 0; i < g.length; i++) {
            if (i == 8) y += Ui.dp(14);
            if (i == 0 || i == 8) { fp.setColor(0xFFFFFFFF); c.drawRoundRect(x, y, sw - Ui.dp(8), y + (i == 0 ? 8 : 4) * rh, Ui.dp(12), Ui.dp(12), fp); }
            if (i == 4) { fp.setColor(0xFF0A84FF); c.drawRoundRect(x + Ui.dp(4), y + Ui.dp(2), sw - Ui.dp(12), y + rh - Ui.dp(2), Ui.dp(9), Ui.dp(9), fp); }
            fp.setColor(col[i]); c.drawRoundRect(x + Ui.dp(14), y + Ui.dp(9), x + Ui.dp(36), y + Ui.dp(31), Ui.dp(5.5f), Ui.dp(5.5f), fp);
            if (i == 4) { fp.setColor(0x55FFFFFF); c.drawRoundRect(x + Ui.dp(14), y + Ui.dp(9), x + Ui.dp(36), y + Ui.dp(31), Ui.dp(5.5f), Ui.dp(5.5f), fp); }
            txt(c, g[i], x + Ui.dp(46), y + rh / 2 + Ui.dp(5), i == 4 ? 0xFFFFFFFF : 0xFF000000, 14, Ui.REG, Paint.Align.LEFT);
            y += rh;
        }
        float px = sw + Ui.dp(10), pw = W - px - Ui.dp(24);
        txt(c, "Multitasking & Gestures", px + pw / 2, Ui.dp(54), 0xFF000000, 17, Ui.BOLD, Paint.Align.CENTER);
        String[] o = {"Full Screen Apps", "Windowed Apps", "Stage Manager"};
        float cw = (pw - Ui.dp(24)) / 3, ch = Math.min(Ui.dp(130), H * 0.26f), cy = Ui.dp(78);
        for (int i = 0; i < 3; i++) {
            float l = px + i * (cw + Ui.dp(12));
            fp.setColor(0xFFFFFFFF); c.drawRoundRect(l, cy, l + cw, cy + ch, Ui.dp(14), Ui.dp(14), fp);
            fp.setColor(i == 1 ? 0xFF6CB7FF : 0xFFE4E7F2); c.drawRoundRect(l + Ui.dp(10), cy + Ui.dp(10), l + cw - Ui.dp(10), cy + ch - Ui.dp(34), Ui.dp(8), Ui.dp(8), fp);
            fp.setColor(0xCCFFFFFF); c.drawRoundRect(l + cw * 0.22f, cy + ch * 0.22f, l + cw * 0.62f, cy + ch * 0.55f, Ui.dp(4), Ui.dp(4), fp);
            Paint rp = Ui.p(i == 1 ? 0xFF0A84FF : 0xFFC7C7CC);
            if (i == 1) { c.drawCircle(l + Ui.dp(22), cy + ch - Ui.dp(17), Ui.dp(7), rp); fp.setColor(0xFFFFFFFF); c.drawCircle(l + Ui.dp(22), cy + ch - Ui.dp(17), Ui.dp(2.8f), fp); }
            else { rp.setStyle(Paint.Style.STROKE); rp.setStrokeWidth(Ui.dp(1.4f)); c.drawCircle(l + Ui.dp(22), cy + ch - Ui.dp(17), Ui.dp(7), rp); }
            txt(c, o[i], l + Ui.dp(36), cy + ch - Ui.dp(12), 0xFF000000, 11.5f, Ui.REG, Paint.Align.LEFT);
        }
        String[] rows = {"Close All Windows After Swiping Home", "Automatically Show and Hide Dock", "\u2022Gestures", "Four & Five Finger App Switching", "Productivity Gestures"};
        boolean[] on = {false, true, false, true, true};
        float ry = cy + ch + Ui.dp(22), rh2 = Ui.dp(48);
        fp.setColor(0xFFFFFFFF); c.drawRoundRect(px, ry, px + pw, ry + 2 * rh2, Ui.dp(14), Ui.dp(14), fp);
        for (int i = 0; i < 2; i++) { txt(c, rows[i], px + Ui.dp(16), ry + i * rh2 + rh2 / 2 + Ui.dp(5), 0xFF000000, 14.5f, Ui.REG, Paint.Align.LEFT); toggle(c, px + pw - Ui.dp(40), ry + i * rh2 + rh2 / 2, on[i]); }
        float gy = ry + 2 * rh2 + Ui.dp(26);
        txt(c, "GESTURES", px + Ui.dp(16), gy - Ui.dp(6), 0xFF6C6C70, 12, Ui.REG, Paint.Align.LEFT);
        fp.setColor(0xFFFFFFFF); c.drawRoundRect(px, gy, px + pw, gy + 2 * rh2, Ui.dp(14), Ui.dp(14), fp);
        for (int i = 0; i < 2; i++) { txt(c, rows[3 + i], px + Ui.dp(16), gy + i * rh2 + rh2 / 2 + Ui.dp(5), 0xFF000000, 14.5f, Ui.REG, Paint.Align.LEFT); toggle(c, px + pw - Ui.dp(40), gy + i * rh2 + rh2 / 2, true); }
    }

    // ---------------------------------------------------------------- touch
    final Runnable lp = new Runnable() { public void run() {
        if (pressed != null && !moved && openApp == null && menuApp == null) { lpFired = true; performHapticFeedback(android.view.HapticFeedbackConstants.LONG_PRESS); showMenu(pressed); }
    } };

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x; downY = y; moved = false; lpFired = false; closing = false;
                if (vt != null) vt.recycle(); vt = VelocityTracker.obtain(); vt.addMovement(e);
                if (openAnim != null && openAnim.isRunning()) { return true; }
                if (openApp != null) { closing = y > H * 0.78f; return true; }
                if (menuApp != null) return true;
                if (pageAnim != null) pageAnim.cancel();
                startPage = pageF; pressed = hit(x, y);
                if (pressed != null && !jiggle) postDelayed(lp, 450);
                invalidate(); return true;
            case MotionEvent.ACTION_MOVE: {
                vt.addMovement(e);
                float dx = x - downX, dy = y - downY;
                if (openApp != null) { if (closing && dy < 0) { openT = Math.max(0f, 1 + dy / (H * 0.65f)); invalidate(); } return true; }
                if (menuApp != null) return true;
                if (!moved && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy)) { moved = true; removeCallbacks(lp); pressed = null; }
                if (moved) { pageF = Math.max(-0.2f, Math.min(pages - 1 + 0.2f, startPage - dx / W)); invalidate(); }
                else if (Math.abs(dy) > slop) { removeCallbacks(lp); pressed = null; }
                return true;
            }
            case MotionEvent.ACTION_UP: case MotionEvent.ACTION_CANCEL: {
                vt.addMovement(e); vt.computeCurrentVelocity(1000);
                removeCallbacks(lp);
                boolean up = e.getActionMasked() == MotionEvent.ACTION_UP;
                float dx = x - downX, dy = y - downY;
                if (openAnim != null && openAnim.isRunning()) return true;
                if (openApp != null) {
                    if (closing && up && (dy < -H * 0.1f || vt.getYVelocity() < -900 || (Math.abs(dy) < slop && y > H - Ui.dp(24)))) animateOpen(false);
                    else if (openT < 1f) animateOpen(true);
                    return true;
                }
                if (menuApp != null) { if (up) menuTap(x, y); return true; }
                App p = pressed; pressed = null;
                if (moved) {
                    int target = Math.round(startPage);
                    if (Math.abs(dx) > W * 0.12f || Math.abs(vt.getXVelocity()) > 900) target += dx < 0 ? 1 : -1;
                    snap(Math.max(0, Math.min(pages - 1, target)));
                } else if (up && !lpFired) {
                    if (jiggle) {
                        if (doneBtn.contains(x, y)) jiggle = false;
                        else if (p != null && !p.dock) { RectF r = screenRect(p); if (Math.hypot(x - (r.left + Ui.dp(2)), y - (r.top + Ui.dp(2))) < Ui.dp(20)) { p.removed = true; layoutApps(); } }
                    } else if (p != null) { ir = screenRect(p); openApp = p; animateOpen(true); }
                }
                if (pageF != Math.round(pageF) && (pageAnim == null || !pageAnim.isRunning())) snap(Math.round(pageF));
                invalidate(); return true;
            }
        }
        return true;
    }

    void menuTap(float x, float y) {
        if (menuRect.contains(x, y)) {
            float rh = Ui.dp(ROW), rel = y - menuRect.top; int i;
            if (rel < 3 * rh) i = (int) (rel / rh); else if (rel < 3 * rh + Ui.dp(SEP)) i = -1; else i = 3 + (int) ((rel - 3 * rh - Ui.dp(SEP)) / rh);
            if (i < 0) return;
            App a = menuApp;
            if (i == 0) { a.removed = true; layoutApps(); menuAnim(menuT, 0, 160); }
            else if (i == 1) menuAnim(menuT, 0, 160);
            else if (i == 2) { jiggle = true; menuAnim(menuT, 0, 160); }
            else { ir = screenRect(a); openApp = a; menuApp = null; menuT = 0; animateOpen(true); }
        } else menuAnim(menuT, 0, 160);
    }

    void snap(int target) {
        if (pageAnim != null) pageAnim.cancel();
        pageAnim = ValueAnimator.ofFloat(pageF, target); pageAnim.setDuration(520); pageAnim.setInterpolator(new Ui.Spring());
        pageAnim.addUpdateListener(v -> { pageF = (float) v.getAnimatedValue(); invalidate(); });
        pageAnim.start();
    }

    void animateOpen(boolean open) {
        if (openAnim != null) openAnim.cancel();
        final float from = openT, to = open ? 1f : 0f;
        openAnim = ValueAnimator.ofFloat(0, 1); openAnim.setDuration(open ? 560 : 480); openAnim.setInterpolator(new Ui.Spring());
        openAnim.addUpdateListener(v -> { openT = Math.max(0f, from + (to - from) * (float) v.getAnimatedValue()); invalidate(); });
        openAnim.addListener(new AnimatorListenerAdapter() { boolean cn; @Override public void onAnimationCancel(Animator a) { cn = true; }
            @Override public void onAnimationEnd(Animator a) { if (cn) return; openT = to; if (!open) { openApp = null; } invalidate(); } });
        openAnim.start();
    }

    boolean handleBack() {
        if (menuApp != null) { menuAnim(menuT, 0, 160); return true; }
        if (openApp != null && (openAnim == null || !openAnim.isRunning())) { animateOpen(false); return true; }
        if (jiggle) { jiggle = false; invalidate(); return true; }
        return false;
    }
}
