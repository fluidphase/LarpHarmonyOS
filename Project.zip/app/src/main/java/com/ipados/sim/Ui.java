package com.ipados.sim;

import android.animation.TimeInterpolator;
import android.content.Context;
import android.graphics.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

final class Ui {
    static float d = 1;
    static void init(Context c) {
        d = c.getResources().getDisplayMetrics().density;
        try {
            Typeface sf = Typeface.createFromAsset(c.getAssets(), "sf.otf");
            REG = sf; MED = sf; LIGHT = sf; THIN = sf; BOLD = Typeface.create(sf, Typeface.BOLD);
        } catch (Exception ignored) { }
        Icons.init(c);
    }
    static float dp(float v) { return v * d; }
    static float lerp(float a, float b, float t) { return a + (b - a) * t; }
    static float cl(float v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

    static Typeface REG = Typeface.create("sans-serif", Typeface.NORMAL), MED = REG, LIGHT = REG, THIN = REG, BOLD = Typeface.create("sans-serif", Typeface.BOLD);
    static final Typeface MONO = Typeface.MONOSPACE;

    static Paint p(int col) { Paint p = new Paint(Paint.ANTI_ALIAS_FLAG); p.setColor(col); return p; }

    private static final Paint TX = new Paint(Paint.ANTI_ALIAS_FLAG);
    /** Shared text paint (size in dp). Don't hold two at once. */
    static Paint tx(int col, float sizeDp, Typeface f, Paint.Align a) {
        TX.setShader(null); TX.setStyle(Paint.Style.FILL); TX.setColor(col);
        TX.setTextSize(dp(sizeDp)); TX.setTypeface(f); TX.setTextAlign(a); return TX;
    }

    /** Critically-ish damped spring with a small, iOS-like overshoot. */
    static class Spring implements TimeInterpolator {
        public float getInterpolation(float t) { return (float) (1 - Math.exp(-8 * t) * Math.cos(8 * t)); }
    }

    static String fmt(String f) { return new SimpleDateFormat(f, Locale.US).format(new Date()); }

    static Bitmap wallpaper(int w, int h) {
        int bw = Math.max(2, w / 3), bh = Math.max(2, h / 3);
        Bitmap b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, bw, bh, new int[]{0xFF0A1A55, 0xFF352B9A, 0xFFAE48C6, 0xFFFF7C8C},
                new float[]{0, .4f, .75f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, bw, bh, p);
        int[] cols = {0x22D3EE, 0x6D5DF6, 0xFF5FA2, 0x3B82F6, 0xFFB86B};
        float[][] pos = {{.18f, .25f, .55f}, {.78f, .22f, .5f}, {.62f, .9f, .6f}, {.08f, .95f, .5f}, {.95f, .8f, .45f}};
        for (int i = 0; i < cols.length; i++) {
            p.setShader(new RadialGradient(bw * pos[i][0], bh * pos[i][1], bw * pos[i][2],
                    0xAA000000 | cols[i], cols[i], Shader.TileMode.CLAMP));
            c.drawRect(0, 0, bw, bh, p);
        }
        return b;
    }

    static void statusBar(Canvas c, int W, boolean left, int col) {
        float y = dp(21);
        if (left) {
            c.drawText(fmt("h:mm a"), dp(22), y, tx(col, 12.5f, MED, Paint.Align.LEFT));
            c.drawText(fmt("EEE MMM d"), dp(86), y, tx(col, 12.5f, MED, Paint.Align.LEFT));
        }
        Paint s = p(col);
        float bw = dp(25), bh = dp(12), bl = W - dp(22) - bw;
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(dp(1)); s.setAlpha(110);
        c.drawRoundRect(bl, y - bh, bl + bw, y, dp(3.5f), dp(3.5f), s);
        s.setStyle(Paint.Style.FILL); s.setAlpha(255);
        c.drawRoundRect(bl + dp(2), y - bh + dp(2), bl + bw - dp(2), y - dp(2), dp(2), dp(2), s);
        s.setAlpha(110);
        c.drawRoundRect(bl + bw + dp(1.5f), y - dp(8), bl + bw + dp(3.2f), y - dp(4), dp(1), dp(1), s);
        c.drawText("100%", bl - dp(8), y, tx(col, 12, MED, Paint.Align.RIGHT));
        // wifi
        float cx = bl - dp(58), cy = y;
        s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(dp(1.7f)); s.setStrokeCap(Paint.Cap.ROUND); s.setAlpha(255);
        for (float r : new float[]{dp(4), dp(7.5f), dp(11)}) c.drawArc(cx - r, cy - r, cx + r, cy + r, -135, 90, false, s);
        s.setStyle(Paint.Style.FILL); c.drawCircle(cx, cy - dp(1), dp(1.4f), s);
    }

    static void ring(Canvas c, float cx, float cy, float r, float prog, int col, float w) {
        Paint s = p(col); s.setStyle(Paint.Style.STROKE); s.setStrokeWidth(dp(w)); s.setStrokeCap(Paint.Cap.ROUND);
        s.setAlpha(70); c.drawCircle(cx, cy, r, s); s.setAlpha(255);
        c.drawArc(cx - r, cy - r, cx + r, cy + r, -90, 360 * prog, false, s);
    }
}
